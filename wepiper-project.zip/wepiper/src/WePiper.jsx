import React, { useState, useEffect, useRef } from "react";

const COLORS = {
  bg: "#0D0D14", surface: "#13131F", card: "#1A1A2E", border: "#2A2A40",
  text: "#F0EFF8", muted: "#8B8AA8", accent: "#A855F7",
};
const gradientText = {
  background: "linear-gradient(135deg, #A78BFA, #EC4899)",
  WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
};
const gradientBg = "linear-gradient(135deg, #7C3AED, #C026D3, #EC4899)";

const MOCK_USERS = [
  { id: 1, name: "Valentina Cruz",  role: ["Emprendedora","Inversora"],    location: "Buenos Aires", bio: "Construyendo el futuro del fintech en LATAM. 2x fundadora, angel investor.",           industries: ["Fintech","Crypto"],      skills: ["Fundraising","Estrategia"],      avatar: "VC", verified: true,  active: true,  match: 94 },
  { id: 2, name: "Mateo Rivera",    role: ["Profesional","Proveedor"],     location: "Medellín",     bio: "Dev full-stack. 8 años construyendo productos escalables para startups.",            industries: ["SaaS","IA"],             skills: ["React","Node.js","AWS"],         avatar: "MR", verified: true,  active: true,  match: 87 },
  { id: 3, name: "Sofía Herrera",   role: ["Inversora"],                   location: "Miami",        bio: "VC partner en Wayra. Foco en rondas seed de edtech y healthtech.",                  industries: ["EdTech","HealthTech"],   skills: ["Due Diligence","Portfolio"],     avatar: "SH", verified: true,  active: true,  match: 82 },
  { id: 4, name: "Lucas Mendoza",   role: ["Emprendedor"],                 location: "Santiago",     bio: "Co-fundador @ GreenLoop. Economía circular para residuos electrónicos.",            industries: ["CleanTech","Hardware"],  skills: ["Operaciones","Marketing"],       avatar: "LM", verified: false, active: true,  match: 76 },
  { id: 5, name: "Andrea Blanco",   role: ["Profesional","Emprendedora"],  location: "Bogotá",       bio: "Growth hacker. Ayudé a 12 startups a pasar de 0 a 10k usuarios.",                   industries: ["SaaS","Marketplace"],   skills: ["SEO","Publicidad Paga"],         avatar: "AB", verified: true,  active: false, match: 71 },
];

// Contactos iniciales (con quienes ya hubo match/conexión)
const INITIAL_CONNECTIONS = [2]; // Mateo ya estaba conectado

const MOCK_POSTS_INIT = [
  { id: 1, author: "Valentina Cruz", avatar: "VC", role: "Inversora",    time: "hace 2h", type: "Busco cofundador/a",     content: "Construyendo un SaaS B2B para scoring crediticio de pymes en LatAm. Busco cofundador/a técnico/a con experiencia en ML. Tenemos $200k pre-seed comprometidos. ¡Escribime!", likes: 34, comments: 8,  connected: false, liked: false },
  { id: 2, author: "Mateo Rivera",   avatar: "MR", role: "Proveedor",    time: "hace 5h", type: "Ofrezco servicios",      content: "Ofrezco servicios de desarrollo full-stack para startups en etapa temprana. Entrego MVPs en 6-8 semanas. Stack: React, Node, PostgreSQL. Arreglos flexibles en equity + cash.", likes: 21, comments: 4,  connected: true,  liked: false },
  { id: 3, author: "Sofía Herrera",  avatar: "SH", role: "Inversora",    time: "hace 1d", type: "Busco inversor/a",       content: "📣 Convocatoria abierta: Wayra acepta aplicaciones para nuestra cohorte Q2 2026. Fundadores de EdTech + HealthTech — cheques de $150k a $300k. Aplicá por el link en bio.", likes: 89, comments: 22, connected: false, liked: false },
  { id: 4, author: "Lucas Mendoza",  avatar: "LM", role: "Emprendedor",  time: "hace 2d", type: "Oportunidad de proyecto", content: "¡GreenLoop lanzó su beta en Santiago! Buscamos socio estratégico en retail para pilotar nuestro programa de recolección de e-waste. Hablemos.", likes: 45, comments: 11, connected: false, liked: false },
];

const MOCK_PROJECTS = [
  { id: 1, name: "CreditFlow", owner: "Valentina Cruz", avatar: "VC", description: "Scoring crediticio con IA para pymes no bancarizadas en LATAM.", industry: "Fintech",   stage: "MVP",        looking: ["Inversor/a","Desarrollador/a"] },
  { id: 2, name: "GreenLoop",  owner: "Lucas Mendoza",  avatar: "LM", description: "Plataforma de economía circular para reciclaje de e-waste.",           industry: "CleanTech", stage: "Crecimiento", looking: ["Proveedor/a","Inversor/a"]   },
  { id: 3, name: "EduPath",    owner: "Andrea Blanco",  avatar: "AB", description: "Recorridos de aprendizaje personalizados para capacitación profesional.", industry: "EdTech",    stage: "Idea",        looking: ["Cofundador/a","Desarrollador/a"] },
];

const MOCK_CHATS_INIT = {
  2: [
    { from: "them", text: "¡Hola! Vi tu perfil, me encanta lo que estás construyendo.", time: "Ayer" },
    { from: "me",   text: "¡Gracias Mateo! También me interesan tus servicios de dev.", time: "Ayer" },
    { from: "them", text: "¿Querés hacer una llamada rápida esta semana?",              time: "hace 2h" },
  ]
};

const INDUSTRIES  = ["Fintech","SaaS","IA/ML","EdTech","HealthTech","CleanTech","Crypto","Hardware","Marketplace","E-commerce"];
const ROLES       = ["Profesional","Emprendedor/a","Inversor/a","Proveedor/a"];
const POST_TYPES  = ["Busco cofundador/a","Busco inversor/a","Ofrezco servicios","Oportunidad de proyecto","Busco colaboración"];
const postColors  = { "Busco cofundador/a":"#6366F1","Busco inversor/a":"#10B981","Ofrezco servicios":"#F59E0B","Oportunidad de proyecto":"#EC4899","Busco colaboración":"#8B5CF6" };
const stageColors = { Idea:"#8B5CF6", MVP:"#3B82F6", Crecimiento:"#10B981", Escalando:"#F59E0B" };

// ── Componentes base ──────────────────────────────────────────────────────────
const Av = ({ initials, size = 40, gradient = gradientBg }) => (
  <div style={{ width:size, height:size, borderRadius:"50%", background:gradient, display:"flex", alignItems:"center", justifyContent:"center", fontSize:size*0.35, fontWeight:700, color:"#fff", flexShrink:0, letterSpacing:"0.02em" }}>{initials}</div>
);
const Badge = ({ children, color = COLORS.accent, small }) => (
  <span style={{ background:color+"22", border:`1px solid ${color}55`, color, borderRadius:20, padding:small?"2px 8px":"4px 10px", fontSize:small?10:11, fontWeight:600, whiteSpace:"nowrap" }}>{children}</span>
);
const Btn = ({ children, onClick, variant="primary", full, small, style={} }) => {
  const s = { primary:{background:gradientBg,color:"#fff",border:"none"}, outline:{background:"transparent",color:COLORS.accent,border:`1.5px solid ${COLORS.accent}`}, ghost:{background:COLORS.surface,color:COLORS.muted,border:`1px solid ${COLORS.border}`} }[variant];
  return <button onClick={onClick} style={{ ...s, borderRadius:12, padding:small?"8px 16px":"12px 20px", fontSize:small?12:14, fontWeight:600, cursor:"pointer", width:full?"100%":"auto", display:"inline-flex", alignItems:"center", justifyContent:"center", gap:6, ...style }}>{children}</button>;
};
const Field = ({ label, type="text", value, onChange, placeholder, icon }) => (
  <div style={{ marginBottom:16 }}>
    {label && <label style={{ display:"block", color:COLORS.muted, fontSize:11, fontWeight:700, marginBottom:6, letterSpacing:"0.07em", textTransform:"uppercase" }}>{label}</label>}
    <div style={{ position:"relative" }}>
      {icon && <span style={{ position:"absolute", left:14, top:"50%", transform:"translateY(-50%)", color:COLORS.muted }}>{icon}</span>}
      <input type={type} value={value} onChange={onChange} placeholder={placeholder} style={{ width:"100%", background:COLORS.card, border:`1.5px solid ${COLORS.border}`, borderRadius:12, padding:icon?"14px 14px 14px 42px":"14px", color:COLORS.text, fontSize:15, outline:"none", boxSizing:"border-box", fontFamily:"inherit" }}
        onFocus={e=>e.target.style.borderColor=COLORS.accent} onBlur={e=>e.target.style.borderColor=COLORS.border} />
    </div>
  </div>
);

// ── Splash ────────────────────────────────────────────────────────────────────
const Splash = ({ onDone }) => {
  useEffect(() => { const t = setTimeout(onDone, 2000); return () => clearTimeout(t); }, []);
  return (
    <div style={{ height:"100%", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", background:COLORS.bg }}>
      <div style={{ width:90, height:90, borderRadius:28, background:gradientBg, display:"flex", alignItems:"center", justifyContent:"center", marginBottom:20, boxShadow:"0 0 60px #A855F755" }}>
        <span style={{ fontSize:42 }}>🎵</span>
      </div>
      <h1 style={{ ...gradientText, fontSize:36, fontWeight:900, margin:0 }}>WePiper</h1>
      <p style={{ color:COLORS.muted, fontSize:14, marginTop:8 }}>Conectá. Colaborá. Construí.</p>
    </div>
  );
};

// ── Auth ──────────────────────────────────────────────────────────────────────
const Auth = ({ onAuth }) => {
  const [view, setView] = useState("landing");
  const [email, setEmail] = useState(""); const [pass, setPass] = useState(""); const [nombre, setNombre] = useState("");

  if (view === "landing") return (
    <div style={{ height:"100%", display:"flex", flexDirection:"column", background:COLORS.bg }}>
      <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32 }}>
        <div style={{ width:80, height:80, borderRadius:24, background:gradientBg, display:"flex", alignItems:"center", justifyContent:"center", marginBottom:24, boxShadow:"0 0 50px #A855F755" }}>
          <span style={{ fontSize:38 }}>🎵</span>
        </div>
        <h1 style={{ ...gradientText, fontSize:34, fontWeight:900, margin:"0 0 12px" }}>WePiper</h1>
        <p style={{ color:COLORS.muted, fontSize:15, textAlign:"center", lineHeight:1.7, maxWidth:280, margin:"0 0 40px" }}>La red profesional para emprendedores, inversores y constructores.</p>
        <div style={{ display:"flex", flexDirection:"column", gap:16, width:"100%", maxWidth:300 }}>
          {[["🤝","Conectá con personas clave en tu industria"],["💡","Descubrí proyectos y oportunidades únicas"],["🚀","Construí tu red y hacé crecer tu negocio"]].map(([icon,text]) => (
            <div key={text} style={{ display:"flex", alignItems:"center", gap:14 }}>
              <div style={{ width:38, height:38, borderRadius:12, background:COLORS.card, border:`1px solid ${COLORS.border}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, flexShrink:0 }}>{icon}</div>
              <span style={{ color:COLORS.muted, fontSize:13, lineHeight:1.5 }}>{text}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ padding:"0 24px 24px" }}>
        <Btn full onClick={() => setView("signup")} style={{ marginBottom:10 }}>Crear cuenta</Btn>
        <Btn full variant="outline" onClick={() => setView("login")}>Iniciar sesión</Btn>
        <button onClick={() => onAuth({ name:"Invitado", roles:[], guest:true })} style={{ width:"100%", background:"none", border:"none", color:COLORS.muted, fontSize:14, marginTop:14, cursor:"pointer", padding:8 }}>Continuar como invitado</button>
        <div style={{ textAlign:"center", marginTop:20, paddingTop:16, borderTop:`1px solid ${COLORS.border}` }}>
          <span style={{ color:COLORS.muted, fontSize:11, letterSpacing:"0.12em", fontStyle:"italic", opacity:0.6 }}>by </span>
          <span style={{ background:"linear-gradient(135deg,#A78BFA,#EC4899)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text", fontSize:12, fontWeight:700, letterSpacing:"0.1em" }}>4His</span>
        </div>
      </div>
    </div>
  );
  if (view === "forgot") return (
    <div style={{ height:"100%", background:COLORS.bg, padding:24, display:"flex", flexDirection:"column" }}>
      <button onClick={() => setView("login")} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer", alignSelf:"flex-start", marginBottom:28 }}>←</button>
      <h2 style={{ color:COLORS.text, fontSize:24, fontWeight:800, marginBottom:8 }}>Recuperar contraseña</h2>
      <p style={{ color:COLORS.muted, fontSize:14, marginBottom:28 }}>Ingresá tu email y te mandamos un link.</p>
      <Field label="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vos@ejemplo.com" icon="✉️" />
      <Btn full onClick={() => setView("verify")}>Enviar link</Btn>
    </div>
  );
  if (view === "verify") return (
    <div style={{ height:"100%", background:COLORS.bg, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32 }}>
      <div style={{ fontSize:56, marginBottom:20 }}>📬</div>
      <h2 style={{ color:COLORS.text, fontSize:22, fontWeight:800, marginBottom:10, textAlign:"center" }}>Revisá tu email</h2>
      <p style={{ color:COLORS.muted, fontSize:14, textAlign:"center", marginBottom:28 }}>Te mandamos un link a <span style={{ color:COLORS.accent }}>{email||"tu email"}</span></p>
      <Btn onClick={() => onAuth({ name:nombre||email.split("@")[0]||"Usuario", email, roles:[], guest:false, isNewUser:true })}>Continuar →</Btn>
    </div>
  );
  if (view === "login") return (
    <div style={{ height:"100%", background:COLORS.bg, padding:24, display:"flex", flexDirection:"column", overflowY:"auto" }}>
      <button onClick={() => setView("landing")} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer", alignSelf:"flex-start", marginBottom:28 }}>←</button>
      <h2 style={{ color:COLORS.text, fontSize:26, fontWeight:800, marginBottom:4 }}>Bienvenido de vuelta</h2>
      <p style={{ color:COLORS.muted, fontSize:14, marginBottom:28 }}>Ingresá a tu cuenta de WePiper</p>
      <Field label="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vos@ejemplo.com" icon="✉️" />
      <Field label="Contraseña" type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••" icon="🔒" />
      <button onClick={() => setView("forgot")} style={{ background:"none", border:"none", color:COLORS.accent, fontSize:13, cursor:"pointer", textAlign:"right", marginBottom:20, padding:0 }}>¿Olvidaste tu contraseña?</button>
      <Btn full onClick={() => onAuth({ name:email.split("@")[0]||"Usuario", email, roles:[], guest:false })}>Ingresar</Btn>
      <div style={{ display:"flex", alignItems:"center", gap:10, margin:"18px 0" }}>
        <div style={{ flex:1, height:1, background:COLORS.border }}/><span style={{ color:COLORS.muted, fontSize:12 }}>o</span><div style={{ flex:1, height:1, background:COLORS.border }}/>
      </div>
      <Btn full variant="ghost" onClick={() => onAuth({ name:"Usuario Google", roles:[], guest:false })}>🔵 Continuar con Google</Btn>
      <p style={{ color:COLORS.muted, fontSize:13, textAlign:"center", marginTop:20 }}>¿No tenés cuenta? <button onClick={() => setView("signup")} style={{ background:"none", border:"none", color:COLORS.accent, cursor:"pointer", fontWeight:600 }}>Registrate</button></p>
    </div>
  );
  if (view === "signup") return (
    <div style={{ height:"100%", background:COLORS.bg, padding:24, display:"flex", flexDirection:"column", overflowY:"auto" }}>
      <button onClick={() => setView("landing")} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer", alignSelf:"flex-start", marginBottom:28 }}>←</button>
      <h2 style={{ color:COLORS.text, fontSize:26, fontWeight:800, marginBottom:4 }}>Crear cuenta</h2>
      <p style={{ color:COLORS.muted, fontSize:14, marginBottom:28 }}>Sumate a la comunidad WePiper</p>
      <Field label="Nombre completo" value={nombre} onChange={e=>setNombre(e.target.value)} placeholder="Tu nombre" icon="👤" />
      <Field label="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vos@ejemplo.com" icon="✉️" />
      <Field label="Contraseña" type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="Mínimo 8 caracteres" icon="🔒" />
      <Btn full onClick={() => setView("verify")} style={{ marginBottom:10 }}>Crear cuenta</Btn>
      <Btn full variant="ghost" onClick={() => onAuth({ name:nombre||"Usuario Google", email, roles:[], guest:false, isNewUser:true })}>🔵 Continuar con Google</Btn>
      <p style={{ color:COLORS.muted, fontSize:13, textAlign:"center", marginTop:20 }}>¿Ya tenés cuenta? <button onClick={() => setView("login")} style={{ background:"none", border:"none", color:COLORS.accent, cursor:"pointer", fontWeight:600 }}>Ingresá</button></p>
    </div>
  );
};

// ── Onboarding ────────────────────────────────────────────────────────────────
const Onboarding = ({ onDone }) => {
  const [selected, setSelected] = useState([]);
  const toggle = r => setSelected(s => s.includes(r)?s.filter(x=>x!==r):[...s,r]);
  const icons = { "Profesional":"👔","Emprendedor/a":"🚀","Inversor/a":"💰","Proveedor/a":"🔧" };
  const descs  = { "Profesional":"Ofrezco mi experiencia y habilidades","Emprendedor/a":"Estoy construyendo una startup o proyecto","Inversor/a":"Financio oportunidades prometedoras","Proveedor/a":"Ofrezco productos o servicios" };
  return (
    <div style={{ height:"100%", background:COLORS.bg, padding:24, display:"flex", flexDirection:"column" }}>
      <div style={{ flex:1, display:"flex", flexDirection:"column", justifyContent:"center" }}>
        <div style={{ textAlign:"center", marginBottom:36 }}>
          <div style={{ fontSize:44, marginBottom:14 }}>👋</div>
          <h2 style={{ color:COLORS.text, fontSize:24, fontWeight:800, margin:"0 0 8px" }}>¿Qué tipo de Piper sos?</h2>
          <p style={{ color:COLORS.muted, fontSize:14 }}>Seleccioná todo lo que aplique — podés cambiarlo después.</p>
        </div>
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {ROLES.map(role => {
            const active = selected.includes(role);
            return (
              <button key={role} onClick={() => toggle(role)} style={{ background:active?`${COLORS.accent}22`:COLORS.card, border:`2px solid ${active?COLORS.accent:COLORS.border}`, borderRadius:14, padding:"14px 18px", cursor:"pointer", display:"flex", alignItems:"center", gap:14, textAlign:"left" }}>
                <span style={{ fontSize:26 }}>{icons[role]}</span>
                <div><div style={{ color:COLORS.text, fontWeight:700, fontSize:15 }}>{role}</div><div style={{ color:COLORS.muted, fontSize:12, marginTop:2 }}>{descs[role]}</div></div>
                {active && <span style={{ marginLeft:"auto", color:COLORS.accent, fontSize:18 }}>✓</span>}
              </button>
            );
          })}
        </div>
      </div>
      <Btn full onClick={() => selected.length>0&&onDone(selected)} style={{ opacity:selected.length===0?0.5:1 }}>Continuar →</Btn>
    </div>
  );
};

// ── Home ──────────────────────────────────────────────────────────────────────
const Home = ({ user, notifications, onClearNotif, onViewUser, onOpenMenu, isGuest }) => {
  const [posts, setPosts]             = useState(MOCK_POSTS_INIT);
  const [showCreate, setShowCreate]   = useState(false);
  const [newPost, setNewPost]         = useState({ type:POST_TYPES[0], content:"" });
  const [commentPost, setCommentPost] = useState(null);
  const [commentText, setCommentText] = useState("");
  const [sharePost, setSharePost]     = useState(null);
  const [showNotif, setShowNotif]     = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const initials = user.name?.split(" ").map(n=>n[0]).join("").slice(0,2)||"U";
  const unread = notifications.filter(n=>!n.read).length;

  const handleLike    = id => setPosts(p => p.map(x => x.id===id?{...x, likes:x.liked?x.likes-1:x.likes+1, liked:!x.liked}:x));
  const handleConnect = id => setPosts(p => p.map(x => x.id===id?{...x, connected:!x.connected}:x));
  const submitComment = () => { if(!commentText.trim()) return; setPosts(p=>p.map(x=>x.id===commentPost?{...x,comments:x.comments+1}:x)); setCommentText(""); setCommentPost(null); };
  const submitShare   = post => {
    const snippet = post.content.length>80?post.content.slice(0,80)+"...":post.content;
    setPosts(p=>[{id:Date.now(),author:user.name,avatar:initials,role:user.roles?.[0]||"Profesional",time:"Ahora",type:post.type,content:`🔁 Compartido: "${snippet}"`,likes:0,comments:0,connected:false,liked:false},...p]);
    setSharePost(null);
  };

  const filteredPosts = searchQuery.trim()
    ? posts.filter(p =>
        p.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.role.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : posts;

  const isOwnPost = (post) => post.author === user.name;

  return (
    <div style={{ height:"100%", display:"flex", flexDirection:"column", background:COLORS.bg }}>
      {/* Header */}
      <div style={{ padding:"18px 18px 10px", borderBottom:`1px solid ${COLORS.border}` }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <button onClick={onOpenMenu} style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:10, width:38, height:38, cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:4, padding:"9px 8px" }}>
              <div style={{ width:16, height:2, background:COLORS.muted, borderRadius:2 }}/>
              <div style={{ width:16, height:2, background:COLORS.muted, borderRadius:2 }}/>
              <div style={{ width:16, height:2, background:COLORS.muted, borderRadius:2 }}/>
            </button>
            <div>
              <div style={{ color:COLORS.muted, fontSize:12 }}>{isGuest ? "Modo invitado" : "Buen día,"}</div>
              <h2 style={{ ...gradientText, fontSize:20, fontWeight:800, margin:0 }}>{isGuest ? "Invitado" : (user.name?.split(" ")[0]||"Piper")}</h2>
            </div>
          </div>
          <div style={{ display:"flex", gap:10, alignItems:"center" }}>
            {/* Campanita con badge */}
            <div style={{ position:"relative" }}>
              <button onClick={() => { setShowNotif(!showNotif); }} style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:10, width:38, height:38, cursor:"pointer", fontSize:16, display:"flex", alignItems:"center", justifyContent:"center" }}>🔔</button>
              {unread > 0 && (
                <div style={{ position:"absolute", top:-4, right:-4, width:18, height:18, background:"#EC4899", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, color:"#fff", fontWeight:700, border:`2px solid ${COLORS.bg}` }}>{unread}</div>
              )}
            </div>
            <Av initials={initials} size={38} />
          </div>
        </div>
        <div style={{ marginTop:12, background:COLORS.card, border:`1px solid ${searchQuery?COLORS.accent:COLORS.border}`, borderRadius:12, padding:"9px 14px", display:"flex", alignItems:"center", gap:8, transition:"border-color 0.2s" }}>
          <span style={{ color:COLORS.muted, fontSize:14 }}>🔍</span>
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Buscá personas, proyectos..."
            style={{ flex:1, background:"none", border:"none", outline:"none", color:COLORS.text, fontSize:14, fontFamily:"inherit" }}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} style={{ background:"none", border:"none", color:COLORS.muted, cursor:"pointer", fontSize:16, padding:0, lineHeight:1 }}>✕</button>
          )}
        </div>
      </div>

      {/* Panel notificaciones */}
      {showNotif && (
        <div style={{ position:"fixed", inset:0, zIndex:200 }} onClick={() => setShowNotif(false)}>
          <div style={{ position:"absolute", top:72, right:16, width:300, background:COLORS.surface, border:`1px solid ${COLORS.border}`, borderRadius:16, boxShadow:"0 8px 32px #00000077", overflow:"hidden" }} onClick={e=>e.stopPropagation()}>
            <div style={{ padding:"14px 16px 10px", display:"flex", justifyContent:"space-between", alignItems:"center", borderBottom:`1px solid ${COLORS.border}` }}>
              <span style={{ color:COLORS.text, fontWeight:700, fontSize:14 }}>Notificaciones</span>
              {unread>0 && <button onClick={onClearNotif} style={{ background:"none", border:"none", color:COLORS.accent, fontSize:12, cursor:"pointer" }}>Marcar leídas</button>}
            </div>
            {notifications.length===0
              ? <div style={{ padding:24, textAlign:"center", color:COLORS.muted, fontSize:13 }}>No hay notificaciones</div>
              : notifications.map(n => (
                <div key={n.id} style={{ padding:"12px 16px", borderBottom:`1px solid ${COLORS.border}`, display:"flex", gap:10, alignItems:"flex-start", background:n.read?"transparent":COLORS.accent+"11" }}>
                  <span style={{ fontSize:20 }}>{n.icon}</span>
                  <div>
                    <div style={{ color:COLORS.text, fontSize:13, lineHeight:1.4 }}>{n.text}</div>
                    <div style={{ color:COLORS.muted, fontSize:11, marginTop:3 }}>{n.time}</div>
                  </div>
                  {!n.read && <div style={{ width:8, height:8, borderRadius:"50%", background:COLORS.accent, flexShrink:0, marginTop:4 }}/>}
                </div>
              ))
            }
          </div>
        </div>
      )}

      <div style={{ flex:1, overflowY:"auto", padding:"10px 14px" }}>
        {/* Box crear post */}
        <div style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:14, padding:14, marginBottom:12 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <Av initials={initials} size={38} />
            <button onClick={() => setShowCreate(true)} style={{ flex:1, background:COLORS.surface, border:`1px solid ${COLORS.border}`, borderRadius:10, padding:"9px 14px", color:COLORS.muted, fontSize:13, textAlign:"left", cursor:"pointer" }}>Compartí una oportunidad...</button>
          </div>
        </div>

        {/* Modal crear */}
        {showCreate && (
          <div style={{ position:"fixed", inset:0, background:"#00000088", zIndex:100, display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
            <div style={{ background:COLORS.surface, borderRadius:"22px 22px 0 0", padding:22 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
                <h3 style={{ color:COLORS.text, margin:0 }}>Crear publicación</h3>
                <button onClick={() => setShowCreate(false)} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer" }}>✕</button>
              </div>
              <label style={{ color:COLORS.muted, fontSize:11, fontWeight:700, letterSpacing:"0.07em", textTransform:"uppercase", display:"block", marginBottom:6 }}>Tipo</label>
              <select value={newPost.type} onChange={e=>setNewPost({...newPost,type:e.target.value})} style={{ width:"100%", background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:10, padding:12, color:COLORS.text, fontSize:14, marginBottom:12 }}>
                {POST_TYPES.map(t=><option key={t}>{t}</option>)}
              </select>
              <textarea value={newPost.content} onChange={e=>setNewPost({...newPost,content:e.target.value})} placeholder="¿Cuál es tu oportunidad?" rows={4} style={{ width:"100%", background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:14, color:COLORS.text, fontSize:14, resize:"none", boxSizing:"border-box", fontFamily:"inherit" }}/>
              <Btn full onClick={() => { if(newPost.content.trim()){setPosts([{id:Date.now(),author:user.name,avatar:initials,role:user.roles?.[0]||"Profesional",time:"Ahora",type:newPost.type,content:newPost.content,likes:0,comments:0,connected:false,liked:false},...posts]);setShowCreate(false);setNewPost({type:POST_TYPES[0],content:""});} }} style={{ marginTop:10 }}>Publicar</Btn>
            </div>
          </div>
        )}

        {/* Modal comentar */}
        {commentPost!==null && (
          <div style={{ position:"fixed", inset:0, background:"#00000088", zIndex:100, display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
            <div style={{ background:COLORS.surface, borderRadius:"22px 22px 0 0", padding:22 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
                <h3 style={{ color:COLORS.text, margin:0 }}>Comentar</h3>
                <button onClick={() => {setCommentPost(null);setCommentText("");}} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer" }}>✕</button>
              </div>
              <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
                <Av initials={initials} size={36}/>
                <textarea value={commentText} onChange={e=>setCommentText(e.target.value)} placeholder="Escribí tu comentario..." rows={3} style={{ flex:1, background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:12, color:COLORS.text, fontSize:14, resize:"none", boxSizing:"border-box", fontFamily:"inherit" }}/>
              </div>
              <Btn full onClick={submitComment} style={{ marginTop:12 }}>Publicar comentario</Btn>
            </div>
          </div>
        )}

        {/* Modal compartir */}
        {sharePost!==null && (
          <div style={{ position:"fixed", inset:0, background:"#00000088", zIndex:100, display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
            <div style={{ background:COLORS.surface, borderRadius:"22px 22px 0 0", padding:22 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
                <h3 style={{ color:COLORS.text, margin:0 }}>Compartir en tu muro</h3>
                <button onClick={() => setSharePost(null)} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer" }}>✕</button>
              </div>
              <div style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:14, marginBottom:16 }}>
                <div style={{ display:"flex", gap:8, alignItems:"center", marginBottom:8 }}>
                  <Av initials={sharePost.avatar} size={30}/>
                  <div><span style={{ color:COLORS.text, fontWeight:700, fontSize:13 }}>{sharePost.author}</span><div style={{ color:COLORS.muted, fontSize:11 }}>{sharePost.role}</div></div>
                </div>
                <p style={{ color:COLORS.muted, fontSize:13, lineHeight:1.4, margin:0 }}>{sharePost.content.slice(0,100)}{sharePost.content.length>100?"...":""}</p>
              </div>
              <Btn full onClick={() => submitShare(sharePost)}>Compartir ahora 🔁</Btn>
            </div>
          </div>
        )}

        {/* Posts */}
        {filteredPosts.length === 0 && searchQuery && (
          <div style={{ textAlign:"center", padding:"32px 0", color:COLORS.muted, fontSize:14 }}>
            No se encontraron resultados para <span style={{ color:COLORS.accent }}>"{searchQuery}"</span>
          </div>
        )}
        {filteredPosts.map(post => (
          <div key={post.id} style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:14, padding:14, marginBottom:10 }}>
            <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
              <Av initials={post.avatar} size={40}/>
              <div style={{ flex:1 }}>
                <button onClick={() => { const u = EXTENDED_USERS.find(x=>x.name===post.author); if(u) onViewUser(u); }} style={{ background:"none", border:"none", padding:0, cursor:"pointer", textAlign:"left" }}>
                  <span style={{ color:COLORS.text, fontWeight:700, fontSize:14, textDecoration:"underline", textDecorationColor:COLORS.border }}>{post.author}</span>
                </button>
                <div style={{ color:COLORS.muted, fontSize:12 }}>{post.role} · {post.time}</div>
              </div>
              <Badge color={postColors[post.type]||COLORS.accent} small>{post.type}</Badge>
            </div>
            <p style={{ color:COLORS.text, fontSize:14, lineHeight:1.5, margin:"0 0 12px" }}>{post.content}</p>
            <div style={{ display:"flex", alignItems:"center", gap:4, borderTop:`1px solid ${COLORS.border}`, paddingTop:10 }}>
              <button onClick={() => !isGuest && handleLike(post.id)} style={{ background:"none", border:"none", color:post.liked?COLORS.accent:COLORS.muted, fontSize:12, cursor:isGuest?"not-allowed":"pointer", display:"flex", alignItems:"center", gap:4, padding:"4px 6px", borderRadius:8, opacity:isGuest?0.4:1 }}>🤝 {post.likes}</button>
              <button onClick={() => !isGuest && setCommentPost(post.id)} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:12, cursor:isGuest?"not-allowed":"pointer", display:"flex", alignItems:"center", gap:4, padding:"4px 6px", borderRadius:8, opacity:isGuest?0.4:1 }}>💬 {post.comments}</button>
              <button onClick={() => !isGuest && setSharePost(post)} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:12, cursor:isGuest?"not-allowed":"pointer", display:"flex", alignItems:"center", gap:4, padding:"4px 6px", borderRadius:8, opacity:isGuest?0.4:1 }}>🔁 Compartir</button>
              {!isOwnPost(post) && !isGuest && (
                <button onClick={() => handleConnect(post.id)} style={{ marginLeft:"auto", background:post.connected?`${COLORS.accent}22`:gradientBg, border:post.connected?`1px solid ${COLORS.accent}`:"none", borderRadius:8, padding:"5px 12px", color:post.connected?COLORS.accent:"#fff", fontSize:12, fontWeight:600, cursor:"pointer" }}>
                  {post.connected ? "✓ Enviado" : "Conectar"}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const EXTENDED_USERS = [
  { id:1,  name:"Valentina Cruz",    role:["Emprendedora","Inversora"],   location:"Buenos Aires", bio:"Construyendo el futuro del fintech en LATAM. 2x fundadora, angel investor.", industries:["Fintech","Crypto"],     skills:["Fundraising","Estrategia"],    avatar:"VC", avatarBg:"linear-gradient(135deg,#7C3AED,#C026D3)", verified:true,  active:true,  match:94, emoji:"🚀" },
  { id:2,  name:"Mateo Rivera",      role:["Profesional","Proveedor"],    location:"Medellín",     bio:"Dev full-stack. 8 años construyendo productos escalables para startups.",    industries:["SaaS","IA"],            skills:["React","Node.js","AWS"],        avatar:"MR", avatarBg:"linear-gradient(135deg,#0EA5E9,#6366F1)", verified:true,  active:true,  match:87, emoji:"💻" },
  { id:3,  name:"Sofía Herrera",     role:["Inversora"],                  location:"Miami",        bio:"VC partner en Wayra. Foco en rondas seed de edtech y healthtech.",           industries:["EdTech","HealthTech"],  skills:["Due Diligence","Portfolio"],   avatar:"SH", avatarBg:"linear-gradient(135deg,#EC4899,#F59E0B)", verified:true,  active:true,  match:82, emoji:"💰" },
  { id:4,  name:"Lucas Mendoza",     role:["Emprendedor"],                location:"Santiago",     bio:"Co-fundador @ GreenLoop. Economía circular para residuos electrónicos.",     industries:["CleanTech","Hardware"], skills:["Operaciones","Marketing"],     avatar:"LM", avatarBg:"linear-gradient(135deg,#10B981,#0EA5E9)", verified:false, active:true,  match:76, emoji:"♻️" },
  { id:5,  name:"Andrea Blanco",     role:["Profesional","Emprendedora"], location:"Bogotá",       bio:"Growth hacker. Ayudé a 12 startups a pasar de 0 a 10k usuarios.",            industries:["SaaS","Marketplace"],  skills:["SEO","Publicidad Paga"],       avatar:"AB", avatarBg:"linear-gradient(135deg,#F59E0B,#EC4899)", verified:true,  active:false, match:71, emoji:"📈" },
  { id:6,  name:"Diego Paredes",     role:["Inversor/a"],                 location:"Lima",         bio:"Socio en Nazca VC. Invertí en 20+ startups de salud y educación.",           industries:["HealthTech","EdTech"],  skills:["Deal Flow","M&A"],             avatar:"DP", avatarBg:"linear-gradient(135deg,#8B5CF6,#EC4899)", verified:true,  active:true,  match:88, emoji:"🏦" },
  { id:7,  name:"Camila Torres",     role:["Emprendedora"],               location:"Ciudad de Mx", bio:"CEO de NutriAI. Revolucionando la nutrición personalizada con inteligencia artificial.", industries:["HealthTech","IA/ML"],   skills:["Producto","UX","Growth"],      avatar:"CT", avatarBg:"linear-gradient(135deg,#10B981,#A855F7)", verified:false, active:true,  match:79, emoji:"🥗" },
  { id:8,  name:"Rodrigo Salas",     role:["Proveedor/a"],                location:"Montevideo",   bio:"Diseñador UX/UI con 10 años en producto digital. Foco en apps de consumo masivo.", industries:["SaaS","Marketplace"],  skills:["Figma","Design Systems"],     avatar:"RS", avatarBg:"linear-gradient(135deg,#F59E0B,#10B981)", verified:true,  active:false, match:68, emoji:"🎨" },
  { id:9,  name:"Natalia Vega",      role:["Inversora","Emprendedora"],   location:"Buenos Aires", bio:"Ex-Mercado Libre. Ahora cofundando mi segunda startup en agtech.",             industries:["AgTech","Marketplace"], skills:["Ops","B2B Sales"],             avatar:"NV", avatarBg:"linear-gradient(135deg,#6366F1,#0EA5E9)", verified:true,  active:true,  match:91, emoji:"🌱" },
  { id:10, name:"Felipe Castro",     role:["Profesional"],                location:"Medellín",     bio:"Data scientist especializado en modelos de riesgo crediticio para LATAM.",    industries:["Fintech","IA/ML"],      skills:["Python","ML","SQL"],           avatar:"FC", avatarBg:"linear-gradient(135deg,#C026D3,#7C3AED)", verified:false, active:true,  match:74, emoji:"🔬" },
];

const Discover = ({ connections, onConnect, onAddNotif, onViewUser, onSentRequest }) => {
  const [idx, setIdx]                   = useState(0);
  const [sent, setSent]                 = useState([]); // ids con solicitud enviada
  const [showMatchAnim, setShowMatchAnim] = useState(false);
  const [lastSent, setLastSent]         = useState(null);
  const [swipeDir, setSwipeDir]         = useState(null);
  const [filterRole, setFilterRole]     = useState(null);
  const [showFilter, setShowFilter]     = useState(false);

  const available = EXTENDED_USERS.filter(u =>
    !connections.includes(u.id) && !sent.includes(u.id) && (!filterRole || u.role.includes(filterRole))
  );
  const u = available[0];
  const nextU = available[1];

  const triggerSwipe = (dir) => {
    if (!u) return;
    setSwipeDir(dir);
    setTimeout(() => {
      setSwipeDir(null);
      if (dir === "right") {
        setSent(s => [...s, u.id]);
        setLastSent(u.name);
        setShowMatchAnim(true);
        onAddNotif({ id:Date.now(), icon:"📨", text:`Solicitud de conexión enviada a ${u.name}.`, time:"Ahora mismo", read:false });
        if (onSentRequest) onSentRequest(u);
        setTimeout(() => { setShowMatchAnim(false); setLastSent(null); }, 2000);
      }
    }, 350);
  };

  const matchColor = u?.match >= 85 ? "#10B981" : u?.match >= 70 ? "#F59E0B" : "#8B8AA8";

  return (
    <div style={{ height:"100%", display:"flex", flexDirection:"column", background:COLORS.bg, overflow:"hidden" }}>

      {/* Header */}
      <div style={{ padding:"14px 16px 10px", borderBottom:`1px solid ${COLORS.border}` }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:6 }}>
          <div>
            <h2 style={{ ...gradientText, fontSize:18, fontWeight:800, margin:0 }}>Match ⚡</h2>
            <div style={{ color:COLORS.muted, fontSize:11 }}>{available.length} Pipers disponibles</div>
          </div>
          <button onClick={() => setShowFilter(!showFilter)} style={{ background:showFilter?`${COLORS.accent}22`:COLORS.card, border:`1px solid ${showFilter?COLORS.accent:COLORS.border}`, borderRadius:10, padding:"6px 12px", color:showFilter?COLORS.accent:COLORS.muted, fontSize:12, cursor:"pointer" }}>⚙️ Filtrar</button>
        </div>
      </div>

      {/* Filter */}
      {showFilter && (
        <div style={{ padding:"10px 16px", background:COLORS.card, borderBottom:`1px solid ${COLORS.border}` }}>
          <p style={{ color:COLORS.muted, fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", margin:"0 0 8px" }}>Filtrar por rol</p>
          <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
            <button onClick={() => setFilterRole(null)} style={{ padding:"4px 12px", borderRadius:20, border:`1.5px solid ${!filterRole?COLORS.accent:COLORS.border}`, background:!filterRole?`${COLORS.accent}22`:"none", color:!filterRole?COLORS.accent:COLORS.muted, fontSize:11, cursor:"pointer" }}>Todos</button>
            {ROLES.map(r => (
              <button key={r} onClick={() => setFilterRole(r)} style={{ padding:"4px 12px", borderRadius:20, border:`1.5px solid ${filterRole===r?COLORS.accent:COLORS.border}`, background:filterRole===r?`${COLORS.accent}22`:"none", color:filterRole===r?COLORS.accent:COLORS.muted, fontSize:11, cursor:"pointer" }}>{r}</button>
            ))}
          </div>
        </div>
      )}

      {/* Sent animation overlay */}
      {showMatchAnim && (
        <div style={{ position:"absolute", inset:0, zIndex:300, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", background:"rgba(0,0,0,0.85)", backdropFilter:"blur(6px)" }}>
          <div style={{ fontSize:64, animation:"matchBounce 0.5s ease", marginBottom:14 }}>📨</div>
          <div style={{ fontSize:22, fontWeight:900, color:"#fff", marginBottom:6 }}>Solicitud enviada</div>
          <div style={{ ...gradientText, fontSize:18, fontWeight:700 }}>{lastSent}</div>
          <div style={{ color:COLORS.muted, fontSize:13, marginTop:8 }}>Te avisamos cuando acepte.</div>
        </div>
      )}

      {/* Card stack */}
      <div style={{ flex:1, padding:"10px 14px 8px", display:"flex", flexDirection:"column", position:"relative" }}>
        {available.length === 0 ? (
          <div style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", textAlign:"center", gap:12 }}>
            <div style={{ fontSize:56 }}>🎉</div>
            <h3 style={{ color:COLORS.text, fontSize:18, fontWeight:800 }}>¡Recorriste todos los Pipers!</h3>
            <p style={{ color:COLORS.muted, fontSize:14 }}>Volvé mañana para nuevos perfiles.</p>
          </div>
        ) : (
          <>
            {/* Card fondo */}
            {nextU && (
              <div style={{ position:"absolute", left:22, right:22, top:14, borderRadius:22, overflow:"hidden", transform:"scale(0.96) translateY(8px)", zIndex:1, opacity:0.5 }}>
                <div style={{ height:130, background:nextU.avatarBg }}/>
              </div>
            )}

            {/* Card principal — draggable */}
            <div
              onMouseDown={e => { const startX=e.clientX; let moved=false; const onMove=ev=>{ const dx=ev.clientX-startX; if(Math.abs(dx)>8) moved=true; if(dx>70){triggerSwipe("right")} else if(dx<-70){triggerSwipe("left")} }; const onUp=()=>{ window.removeEventListener("mousemove",onMove); window.removeEventListener("mouseup",onUp); }; window.addEventListener("mousemove",onMove); window.addEventListener("mouseup",onUp); }}
              onTouchStart={e => { const startX=e.touches[0].clientX; const onMove=ev=>{ const dx=ev.touches[0].clientX-startX; if(dx>70){triggerSwipe("right")} else if(dx<-70){triggerSwipe("left")} }; const onEnd=()=>{ window.removeEventListener("touchmove",onMove); window.removeEventListener("touchend",onEnd); }; window.addEventListener("touchmove",onMove); window.addEventListener("touchend",onEnd); }}
              style={{
                flex:1, borderRadius:22, overflow:"hidden", zIndex:2, position:"relative",
                transform: swipeDir==="right" ? "translateX(110%) rotate(12deg)" : swipeDir==="left" ? "translateX(-110%) rotate(-12deg)" : "none",
                transition: swipeDir ? "transform 0.35s cubic-bezier(0.4,0,0.2,1)" : "none",
                boxShadow:"0 8px 32px rgba(0,0,0,0.4)", userSelect:"none", cursor:"grab",
              }}>
              {/* Stamp overlays */}
              {swipeDir === "right" && (
                <div style={{ position:"absolute", top:24, left:20, zIndex:10, background:"#10B98188", border:"3px solid #10B981", borderRadius:10, padding:"4px 14px", transform:"rotate(-15deg)" }}>
                  <span style={{ color:"#fff", fontWeight:900, fontSize:18 }}>ENVIADO ✓</span>
                </div>
              )}
              {swipeDir === "left" && (
                <div style={{ position:"absolute", top:24, right:20, zIndex:10, background:"#EF444488", border:"3px solid #EF4444", borderRadius:10, padding:"4px 14px", transform:"rotate(15deg)" }}>
                  <span style={{ color:"#fff", fontWeight:900, fontSize:18 }}>SKIP ✕</span>
                </div>
              )}

              {/* Photo */}
              <div style={{ height:240, background:u.avatarBg, position:"relative", display:"flex", alignItems:"center", justifyContent:"center" }}>
                <div style={{ width:96, height:96, borderRadius:"50%", background:"rgba(255,255,255,0.2)", backdropFilter:"blur(8px)", border:"3px solid rgba(255,255,255,0.4)", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:2 }}>
                  <span style={{ fontSize:32 }}>{u.emoji}</span>
                  <span style={{ color:"#fff", fontSize:14, fontWeight:800 }}>{u.avatar}</span>
                </div>
                <div style={{ position:"absolute", top:14, right:14, background:"rgba(0,0,0,0.55)", backdropFilter:"blur(6px)", borderRadius:20, padding:"5px 12px", display:"flex", alignItems:"center", gap:5 }}>
                  <div style={{ width:8, height:8, borderRadius:"50%", background:matchColor }}/>
                  <span style={{ color:"#fff", fontWeight:800, fontSize:13 }}>{u.match}% match</span>
                </div>
                {u.active && (
                  <div style={{ position:"absolute", top:14, left:14, background:"rgba(16,185,129,0.25)", border:"1px solid rgba(16,185,129,0.5)", borderRadius:20, padding:"4px 10px" }}>
                    <span style={{ color:"#10B981", fontSize:11, fontWeight:700 }}>● Online</span>
                  </div>
                )}
                <div style={{ position:"absolute", bottom:0, left:0, right:0, height:80, background:"linear-gradient(to bottom, transparent, #1A1A2E)" }}/>
                <div style={{ position:"absolute", bottom:12, left:16, right:16 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <button onClick={e => { e.stopPropagation(); onViewUser(u); }} style={{ background:"none", border:"none", padding:0, cursor:"pointer", textAlign:"left" }}>
                      <h3 style={{ color:"#fff", fontSize:18, fontWeight:800, margin:0, textDecoration:"underline", textDecorationColor:"rgba(255,255,255,0.4)" }}>{u.name}</h3>
                    </button>
                    {u.verified && <span style={{ fontSize:14 }}>✅</span>}
                  </div>
                  <div style={{ color:"rgba(255,255,255,0.7)", fontSize:12 }}>📍 {u.location}</div>
                </div>
              </div>

              {/* Info */}
              <div style={{ background:COLORS.card, padding:"12px 16px" }}>
                <div style={{ display:"flex", gap:5, flexWrap:"wrap", marginBottom:8 }}>
                  {u.role.map(r => <Badge key={r} small>{r}</Badge>)}
                </div>
                <p style={{ color:COLORS.text, fontSize:13, lineHeight:1.5, margin:"0 0 8px" }}>{u.bio}</p>
                <div style={{ display:"flex", gap:5, flexWrap:"wrap" }}>
                  {u.industries.map(i => <Badge key={i} color="#F59E0B" small>{i}</Badge>)}
                  {u.skills.slice(0,2).map(s => <Badge key={s} color={COLORS.muted} small>{s}</Badge>)}
                </div>
              </div>
            </div>

            {/* Botones — proporciones equilibradas */}
            <div style={{ display:"flex", gap:10, marginTop:10, alignItems:"stretch" }}>
              <button onClick={() => triggerSwipe("left")} style={{ width:56, height:52, borderRadius:14, background:COLORS.card, border:`2px solid #EF444444`, fontSize:20, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, transition:"transform 0.15s" }}
                onMouseEnter={e=>e.currentTarget.style.transform="scale(1.05)"} onMouseLeave={e=>e.currentTarget.style.transform="scale(1)"}>
                ✕
              </button>
              <button onClick={() => triggerSwipe("right")} style={{ flex:1, height:52, borderRadius:14, background:gradientBg, border:"none", fontSize:14, fontWeight:700, color:"#fff", cursor:"pointer", boxShadow:"0 4px 18px rgba(168,85,247,0.35)", display:"flex", alignItems:"center", justifyContent:"center", gap:6, transition:"transform 0.15s" }}
                onMouseEnter={e=>e.currentTarget.style.transform="scale(1.02)"} onMouseLeave={e=>e.currentTarget.style.transform="scale(1)"}>
                Enviar solicitud 🤝
              </button>
            </div>
          </>
        )}
      </div>
      <style>{`@keyframes matchBounce { 0%{transform:scale(0)} 60%{transform:scale(1.2)} 100%{transform:scale(1)} }`}</style>
    </div>
  );
};

// ── Proyectos ─────────────────────────────────────────────────────────────────
const Projects = () => {
  const [projects, setProjects]   = useState(MOCK_PROJECTS);
  const [showCreate, setShowCreate] = useState(false);
  const [requested, setRequested] = useState([]); // ids de proyectos con solicitud enviada
  const [form, setForm]           = useState({ name:"", description:"", industry:INDUSTRIES[0], stage:"Idea", looking:[] });

  const toggleL   = l => setForm(f => ({...f, looking:f.looking.includes(l)?f.looking.filter(x=>x!==l):[...f.looking,l]}));
  const stages    = ["Idea","MVP","Crecimiento","Escalando"];
  const lookingOpts = ["Inversor/a","Cofundador/a","Desarrollador/a","Proveedor/a","Diseñador/a"];

  const handleRequest = (id) => {
    if (requested.includes(id)) return;
    setRequested(r => [...r, id]);
  };

  return (
    <div style={{ height:"100%", display:"flex", flexDirection:"column", background:COLORS.bg }}>
      <div style={{ padding:"18px 18px 10px", display:"flex", alignItems:"center", justifyContent:"space-between", borderBottom:`1px solid ${COLORS.border}` }}>
        <h2 style={{ ...gradientText, fontSize:20, fontWeight:800, margin:0 }}>Proyectos</h2>
        <Btn small onClick={() => setShowCreate(true)}>+ Nuevo</Btn>
      </div>

      {showCreate && (
        <div style={{ position:"fixed", inset:0, background:"#00000088", zIndex:100, display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
          <div style={{ background:COLORS.surface, borderRadius:"22px 22px 0 0", padding:22, maxHeight:"85vh", overflowY:"auto" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
              <h3 style={{ color:COLORS.text, margin:0 }}>Crear proyecto</h3>
              <button onClick={() => setShowCreate(false)} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer" }}>✕</button>
            </div>
            <Field label="Nombre del proyecto" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="ej. HealthIA"/>
            <div style={{ marginBottom:14 }}>
              <label style={{ display:"block", color:COLORS.muted, fontSize:11, fontWeight:700, marginBottom:6, letterSpacing:"0.07em", textTransform:"uppercase" }}>Descripción</label>
              <textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="¿Qué estás construyendo?" rows={3} style={{ width:"100%", background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:14, color:COLORS.text, fontSize:14, resize:"none", boxSizing:"border-box", fontFamily:"inherit" }}/>
            </div>
            <div style={{ marginBottom:14 }}>
              <label style={{ display:"block", color:COLORS.muted, fontSize:11, fontWeight:700, marginBottom:6, letterSpacing:"0.07em", textTransform:"uppercase" }}>Industria</label>
              <select value={form.industry} onChange={e=>setForm({...form,industry:e.target.value})} style={{ width:"100%", background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:10, padding:12, color:COLORS.text, fontSize:14 }}>
                {INDUSTRIES.map(i=><option key={i}>{i}</option>)}
              </select>
            </div>
            <div style={{ marginBottom:14 }}>
              <label style={{ display:"block", color:COLORS.muted, fontSize:11, fontWeight:700, marginBottom:8, letterSpacing:"0.07em", textTransform:"uppercase" }}>Etapa</label>
              <div style={{ display:"flex", gap:6 }}>
                {stages.map(s=><button key={s} onClick={() => setForm({...form,stage:s})} style={{ flex:1, padding:"8px 2px", borderRadius:10, border:`2px solid ${form.stage===s?(stageColors[s]||COLORS.accent):COLORS.border}`, background:form.stage===s?(stageColors[s]||COLORS.accent)+"22":COLORS.card, color:form.stage===s?(stageColors[s]||COLORS.accent):COLORS.muted, fontSize:11, fontWeight:600, cursor:"pointer" }}>{s}</button>)}
              </div>
            </div>
            <div style={{ marginBottom:18 }}>
              <label style={{ display:"block", color:COLORS.muted, fontSize:11, fontWeight:700, marginBottom:8, letterSpacing:"0.07em", textTransform:"uppercase" }}>Busco</label>
              <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                {lookingOpts.map(l=><button key={l} onClick={() => toggleL(l)} style={{ padding:"5px 12px", borderRadius:20, border:`2px solid ${form.looking.includes(l)?COLORS.accent:COLORS.border}`, background:form.looking.includes(l)?COLORS.accent+"22":COLORS.card, color:form.looking.includes(l)?COLORS.accent:COLORS.muted, fontSize:12, fontWeight:600, cursor:"pointer" }}>{l}</button>)}
              </div>
            </div>
            <Btn full onClick={() => { if(form.name.trim()){setProjects([{id:Date.now(),name:form.name,owner:"Vos",avatar:"YO",description:form.description,industry:form.industry,stage:form.stage,looking:form.looking},...projects]);setShowCreate(false);} }}>Crear proyecto</Btn>
          </div>
        </div>
      )}

      <div style={{ flex:1, overflowY:"auto", padding:"10px 14px" }}>
        {projects.map(p => {
          const isRequested = requested.includes(p.id);
          return (
            <div key={p.id} style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:14, padding:14, marginBottom:10 }}>
              <div style={{ display:"flex", alignItems:"flex-start", gap:10, marginBottom:10 }}>
                <Av initials={p.avatar} size={42}/>
                <div style={{ flex:1 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <h3 style={{ color:COLORS.text, fontSize:16, fontWeight:800, margin:0 }}>{p.name}</h3>
                    <span style={{ background:(stageColors[p.stage]||COLORS.accent)+"22", color:stageColors[p.stage]||COLORS.accent, borderRadius:20, padding:"2px 10px", fontSize:11, fontWeight:700 }}>{p.stage}</span>
                  </div>
                  <div style={{ color:COLORS.muted, fontSize:12, marginTop:2 }}>por {p.owner}</div>
                </div>
              </div>
              <p style={{ color:COLORS.text, fontSize:13, lineHeight:1.5, margin:"0 0 10px" }}>{p.description}</p>
              <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:12 }}>
                <Badge color="#F59E0B" small>{p.industry}</Badge>
                {p.looking.map(l=><Badge key={l} color={COLORS.accent} small>Busca {l}</Badge>)}
              </div>

              {/* Botón con estado */}
              {isRequested ? (
                <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:8, background:"#10B98122", border:"1px solid #10B98155", borderRadius:10, padding:"10px 16px" }}>
                  <span style={{ fontSize:16 }}>✅</span>
                  <span style={{ color:"#10B981", fontSize:13, fontWeight:600 }}>Solicitud enviada</span>
                </div>
              ) : (
                <Btn full variant="outline" small onClick={() => handleRequest(p.id)}>Solicitar unirme</Btn>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ── Mensajes ──────────────────────────────────────────────────────────────────
const Messages = ({ user, connections }) => {
  const [activeChat, setActiveChat]   = useState(null);
  const [input, setInput]             = useState("");
  const [chats, setChats]             = useState(MOCK_CHATS_INIT);
  const [showNewChat, setShowNewChat] = useState(false);

  const send = () => {
    if (!input.trim()||!activeChat) return;
    setChats(c => ({...c, [activeChat]:[...(c[activeChat]||[]),{from:"me",text:input,time:"Ahora"}]}));
    setInput("");
  };

  // Contactos = usuarios conectados
  const connectedUsers = MOCK_USERS.filter(u => connections.includes(u.id));
  // Conversaciones activas (que tienen mensajes)
  const activeConvos   = connectedUsers.filter(u => chats[u.id]);
  // Contactos sin conversación aún
  const noConvoUsers   = connectedUsers.filter(u => !chats[u.id]);

  const startChat = (userId) => {
    if (!chats[userId]) setChats(c => ({...c, [userId]:[]}));
    setActiveChat(userId);
    setShowNewChat(false);
  };

  // ── Vista chat ──
  if (activeChat) {
    const contact = MOCK_USERS.find(u => u.id===activeChat);
    const msgs = chats[activeChat]||[];
    return (
      <div style={{ height:"100%", display:"flex", flexDirection:"column", background:COLORS.bg }}>
        <div style={{ padding:"14px 18px", display:"flex", alignItems:"center", gap:10, borderBottom:`1px solid ${COLORS.border}`, background:COLORS.surface }}>
          <button onClick={() => setActiveChat(null)} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer" }}>←</button>
          <Av initials={contact?.avatar||"?"} size={38}/>
          <div>
            <div style={{ color:COLORS.text, fontWeight:700 }}>{contact?.name}</div>
            <div style={{ color:"#10B981", fontSize:12 }}>● {contact?.active?"En línea":"Conectado"}</div>
          </div>
        </div>
        <div style={{ flex:1, overflowY:"auto", padding:14, display:"flex", flexDirection:"column", gap:8 }}>
          {msgs.length===0 && (
            <div style={{ textAlign:"center", marginTop:40 }}>
              <div style={{ fontSize:36, marginBottom:10 }}>👋</div>
              <p style={{ color:COLORS.muted, fontSize:14 }}>¡Empezá la conversación con {contact?.name?.split(" ")[0]}!</p>
            </div>
          )}
          {msgs.map((m,i) => (
            <div key={i} style={{ display:"flex", justifyContent:m.from==="me"?"flex-end":"flex-start" }}>
              <div style={{ background:m.from==="me"?gradientBg:COLORS.card, borderRadius:m.from==="me"?"18px 18px 4px 18px":"18px 18px 18px 4px", padding:"10px 14px", maxWidth:"75%", border:m.from==="me"?"none":`1px solid ${COLORS.border}` }}>
                <p style={{ color:"#fff", fontSize:14, margin:"0 0 4px", lineHeight:1.4 }}>{m.text}</p>
                <span style={{ color:"rgba(255,255,255,0.6)", fontSize:10 }}>{m.time}</span>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding:"10px 14px", borderTop:`1px solid ${COLORS.border}`, display:"flex", gap:10 }}>
          <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Escribí un mensaje..." style={{ flex:1, background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:24, padding:"11px 16px", color:COLORS.text, fontSize:14, outline:"none", fontFamily:"inherit" }}/>
          <button onClick={send} style={{ background:gradientBg, border:"none", borderRadius:"50%", width:44, height:44, fontSize:18, cursor:"pointer", flexShrink:0 }}>➤</button>
        </div>
      </div>
    );
  }

  // ── Vista lista ──
  return (
    <div style={{ height:"100%", display:"flex", flexDirection:"column", background:COLORS.bg }}>
      <div style={{ padding:"18px 18px 10px", borderBottom:`1px solid ${COLORS.border}`, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <h2 style={{ ...gradientText, fontSize:20, fontWeight:800, margin:0 }}>Mensajes</h2>
        <button onClick={() => setShowNewChat(true)} style={{ background:gradientBg, border:"none", borderRadius:10, padding:"7px 14px", color:"#fff", fontSize:12, fontWeight:600, cursor:"pointer" }}>+ Nuevo chat</button>
      </div>

      {/* Modal nuevo chat */}
      {showNewChat && (
        <div style={{ position:"fixed", inset:0, background:"#00000088", zIndex:100, display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
          <div style={{ background:COLORS.surface, borderRadius:"22px 22px 0 0", padding:22, maxHeight:"60vh", display:"flex", flexDirection:"column" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
              <h3 style={{ color:COLORS.text, margin:0 }}>Nuevo chat</h3>
              <button onClick={() => setShowNewChat(false)} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer" }}>✕</button>
            </div>
            <p style={{ color:COLORS.muted, fontSize:13, marginBottom:14 }}>Tus contactos conectados:</p>
            <div style={{ overflowY:"auto", flex:1 }}>
              {connectedUsers.length===0 ? (
                <p style={{ color:COLORS.muted, fontSize:14, textAlign:"center", padding:20 }}>No tenés contactos aún. ¡Conectate con alguien primero!</p>
              ) : connectedUsers.map(u => (
                <div key={u.id} onClick={() => startChat(u.id)} style={{ display:"flex", alignItems:"center", gap:12, padding:"12px 4px", borderBottom:`1px solid ${COLORS.border}`, cursor:"pointer" }}
                  onMouseEnter={e=>e.currentTarget.style.background=COLORS.card+"88"}
                  onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <div style={{ position:"relative" }}>
                    <Av initials={u.avatar} size={46}/>
                    {u.active && <div style={{ position:"absolute", bottom:1, right:1, width:11, height:11, background:"#10B981", borderRadius:"50%", border:`2px solid ${COLORS.surface}` }}/>}
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ color:COLORS.text, fontWeight:700 }}>{u.name}</div>
                    <div style={{ color:COLORS.muted, fontSize:12 }}>{u.role.join(", ")} · {u.location}</div>
                  </div>
                  <span style={{ color:COLORS.accent, fontSize:18 }}>→</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div style={{ flex:1, overflowY:"auto" }}>
        {/* Conversaciones activas */}
        {activeConvos.map(u => {
          const lastMsg = chats[u.id]?.slice(-1)[0];
          return (
            <div key={u.id} onClick={() => setActiveChat(u.id)} style={{ display:"flex", alignItems:"center", gap:12, padding:"13px 18px", borderBottom:`1px solid ${COLORS.border}`, cursor:"pointer" }}
              onMouseEnter={e=>e.currentTarget.style.background=COLORS.card}
              onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
              <div style={{ position:"relative" }}>
                <Av initials={u.avatar} size={48}/>
                {u.active && <div style={{ position:"absolute", bottom:2, right:2, width:11, height:11, background:"#10B981", borderRadius:"50%", border:`2px solid ${COLORS.bg}` }}/>}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ display:"flex", justifyContent:"space-between" }}>
                  <span style={{ color:COLORS.text, fontWeight:700 }}>{u.name}</span>
                  <span style={{ color:COLORS.muted, fontSize:12 }}>hace 2h</span>
                </div>
                <div style={{ color:COLORS.muted, fontSize:13, marginTop:2 }}>{lastMsg ? (lastMsg.from==="me"?"Vos: ":"")+lastMsg.text.slice(0,40)+"..." : "Sin mensajes aún"}</div>
              </div>
            </div>
          );
        })}

        {/* Sección contactos sin chat */}
        {noConvoUsers.length > 0 && (
          <>
            <div style={{ padding:"12px 18px 6px" }}>
              <span style={{ color:COLORS.muted, fontSize:11, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em" }}>Contactos</span>
            </div>
            {noConvoUsers.map(u => (
              <div key={u.id} onClick={() => startChat(u.id)} style={{ display:"flex", alignItems:"center", gap:12, padding:"11px 18px", borderBottom:`1px solid ${COLORS.border}`, cursor:"pointer" }}
                onMouseEnter={e=>e.currentTarget.style.background=COLORS.card}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <div style={{ position:"relative" }}>
                  <Av initials={u.avatar} size={44}/>
                  {u.active && <div style={{ position:"absolute", bottom:2, right:2, width:10, height:10, background:"#10B981", borderRadius:"50%", border:`2px solid ${COLORS.bg}` }}/>}
                </div>
                <div style={{ flex:1 }}>
                  <span style={{ color:COLORS.text, fontWeight:600 }}>{u.name}</span>
                  <div style={{ color:COLORS.muted, fontSize:12 }}>{u.role[0]} · {u.location}</div>
                </div>
                <span style={{ color:COLORS.muted, fontSize:12 }}>Iniciar chat →</span>
              </div>
            ))}
          </>
        )}

        {connectedUsers.length===0 && (
          <div style={{ padding:32, textAlign:"center" }}>
            <div style={{ fontSize:38, marginBottom:10 }}>💬</div>
            <p style={{ color:COLORS.muted, fontSize:14 }}>Conectate con más Pipers para desbloquear mensajes.</p>
          </div>
        )}
      </div>
    </div>
  );
};

// ── Perfil ────────────────────────────────────────────────────────────────────
const ALL_INDUSTRIES = ["Fintech","SaaS","IA/ML","EdTech","HealthTech","CleanTech","Crypto","Hardware","Marketplace","E-commerce","Retail","Logística","AgTech","PropTech","LegalTech"];
const ALL_SKILLS     = ["React","Node.js","Python","Java","Fundraising","Ventas","Marketing","SEO","Diseño UX","Diseño UI","Operaciones","Estrategia","Producto","Data Science","Blockchain","Cloud","DevOps","Liderazgo","Finanzas","Comunicación"];
const ALL_ROLES      = ["Profesional","Emprendedor/a","Inversor/a","Proveedor/a"];

const Profile = ({ user, onLogout }) => {
  const [editing, setEditing]     = useState(false);
  const [photo, setPhoto]         = useState(null); // base64 o null
  const [bio, setBio]             = useState("Conectando emprendedores e inversores en LATAM. Construyendo la próxima ola de innovación.");
  const [name, setName]           = useState(user.name || "Tu nombre");
  const [location, setLocation]   = useState("Buenos Aires, Argentina");
  const [roles, setRoles]         = useState(user.roles || ["Emprendedor/a"]);
  const [industries, setInds]     = useState(["Fintech","IA/ML","Marketplace"]);
  const [skills, setSkills]       = useState(["Fundraising","Estrategia","Marketing","Producto"]);
  const [verified, setVerified]   = useState(false);
  const [verifyStep, setVerifyStep] = useState(null); // null | 'intro' | 'dni_front' | 'dni_back' | 'selfie' | 'processing' | 'done'
  const [dniFront, setDnifront]   = useState(null);
  const [dniBack, setDniback]     = useState(null);
  const [selfie, setSelfie]       = useState(null);

  const initials = name.split(" ").map(n=>n[0]).join("").slice(0,2)||"U";

  const toggleRole = r => setRoles(prev => prev.includes(r) ? prev.filter(x=>x!==r) : [...prev,r]);
  const toggleInd  = i => setInds(prev  => prev.includes(i) ? prev.filter(x=>x!==i) : [...prev,i]);
  const toggleSkill= s => setSkills(prev=> prev.includes(s) ? prev.filter(x=>x!==s) : [...prev,s]);

  const handlePhoto = e => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setPhoto(ev.target.result);
    reader.readAsDataURL(file);
  };

  const handleDniImg = (setter) => (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setter(ev.target.result);
    reader.readAsDataURL(file);
  };

  const handleVerifyFinish = () => {
    setVerifyStep("processing");
    setTimeout(() => { setVerifyStep("done"); setVerified(true); }, 2200);
  };

  // ── Modal verificación ──
  const VerifyModal = () => {
    if (verifyStep === "intro") return (
      <ModalShell title="Verificar perfil" onClose={() => setVerifyStep(null)}>
        <div style={{ textAlign:"center", padding:"8px 0 16px" }}>
          <div style={{ fontSize:48, marginBottom:14 }}>🛡️</div>
          <h3 style={{ color:COLORS.text, fontSize:17, fontWeight:800, margin:"0 0 8px" }}>Verificá tu identidad</h3>
          <p style={{ color:COLORS.muted, fontSize:13, lineHeight:1.6, marginBottom:20 }}>Para obtener el badge de perfil verificado necesitás subir una foto de tu DNI y hacer una validación facial.</p>
          <div style={{ display:"flex", flexDirection:"column", gap:10, marginBottom:20 }}>
            {[["📄","Foto del frente de tu DNI"],["📄","Foto del dorso de tu DNI"],["🤳","Selfie de validación facial"]].map(([icon,txt])=>(
              <div key={txt} style={{ display:"flex", alignItems:"center", gap:12, background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:"10px 14px" }}>
                <span style={{ fontSize:20 }}>{icon}</span>
                <span style={{ color:COLORS.text, fontSize:13 }}>{txt}</span>
              </div>
            ))}
          </div>
          <Btn full onClick={() => setVerifyStep("dni_front")}>Empezar →</Btn>
        </div>
      </ModalShell>
    );

    if (verifyStep === "dni_front") return (
      <ModalShell title="DNI — Frente" onClose={() => setVerifyStep(null)} back={() => setVerifyStep("intro")}>
        <VerifyUploadStep
          icon="📄" label="Frente del DNI" hint="Asegurate de que el número y tu foto sean legibles."
          preview={dniFront} onFile={handleDniImg(setDnifront)}
          onNext={() => setVerifyStep("dni_back")} nextLabel="Continuar →" disabled={!dniFront}
        />
      </ModalShell>
    );

    if (verifyStep === "dni_back") return (
      <ModalShell title="DNI — Dorso" onClose={() => setVerifyStep(null)} back={() => setVerifyStep("dni_front")}>
        <VerifyUploadStep
          icon="📄" label="Dorso del DNI" hint="Incluí el código de barras o QR si está presente."
          preview={dniBack} onFile={handleDniImg(setDniback)}
          onNext={() => setVerifyStep("selfie")} nextLabel="Continuar →" disabled={!dniBack}
        />
      </ModalShell>
    );

    if (verifyStep === "selfie") return (
      <ModalShell title="Selfie de validación" onClose={() => setVerifyStep(null)} back={() => setVerifyStep("dni_back")}>
        <VerifyUploadStep
          icon="🤳" label="Selfie con tu cara visible" hint="Mirá a la cámara, buena iluminación y sin lentes de sol."
          preview={selfie} onFile={handleDniImg(setSelfie)}
          onNext={handleVerifyFinish} nextLabel="Enviar para validar" disabled={!selfie}
        />
      </ModalShell>
    );

    if (verifyStep === "processing") return (
      <ModalShell title="Validando..." onClose={null}>
        <div style={{ textAlign:"center", padding:"24px 0" }}>
          <div style={{ fontSize:48, marginBottom:16, animation:"spin 1.5s linear infinite", display:"inline-block" }}>⏳</div>
          <p style={{ color:COLORS.muted, fontSize:14 }}>Estamos verificando tu identidad. Puede tardar unos segundos...</p>
          <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>
        </div>
      </ModalShell>
    );

    if (verifyStep === "done") return (
      <ModalShell title="" onClose={() => setVerifyStep(null)}>
        <div style={{ textAlign:"center", padding:"24px 0" }}>
          <div style={{ fontSize:56, marginBottom:16 }}>✅</div>
          <h3 style={{ color:COLORS.text, fontSize:18, fontWeight:800, margin:"0 0 8px" }}>¡Perfil verificado!</h3>
          <p style={{ color:COLORS.muted, fontSize:14, marginBottom:24 }}>Tu badge de verificación ya está activo en tu perfil.</p>
          <Btn full onClick={() => setVerifyStep(null)}>Cerrar</Btn>
        </div>
      </ModalShell>
    );
    return null;
  };

  return (
    <div style={{ height:"100%", overflowY:"auto", background:COLORS.bg }}>
      {/* Verificación modal */}
      {verifyStep && <VerifyModal/>}

      {/* Cover */}
      <div style={{ height:110, background:gradientBg, position:"relative" }}>
        <button style={{ position:"absolute", top:14, right:14, background:"rgba(255,255,255,0.2)", border:"none", borderRadius:10, padding:"7px 12px", color:"#fff", fontSize:13, cursor:"pointer" }}
          onClick={() => { if(editing) setEditing(false); else setEditing(true); }}>
          {editing ? "💾 Guardar" : "✏️ Editar"}
        </button>
      </div>

      <div style={{ padding:"0 18px 80px" }}>
        {/* Foto de perfil */}
        <div style={{ marginTop:-36, marginBottom:12, position:"relative", width:"fit-content" }}>
          {photo
            ? <img src={photo} alt="perfil" style={{ width:72, height:72, borderRadius:"50%", objectFit:"cover", border:`3px solid ${COLORS.bg}` }}/>
            : <Av initials={initials} size={72}/>
          }
          {editing && (
            <label style={{ position:"absolute", bottom:0, right:0, width:26, height:26, background:gradientBg, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", border:`2px solid ${COLORS.bg}`, fontSize:13 }}>
              📷
              <input type="file" accept="image/*" onChange={handlePhoto} style={{ display:"none" }}/>
            </label>
          )}
        </div>

        {/* Nombre y ubicación */}
        {editing ? (
          <div style={{ marginBottom:10 }}>
            <input value={name} onChange={e=>setName(e.target.value)} style={{ width:"100%", background:COLORS.card, border:`1.5px solid ${COLORS.accent}`, borderRadius:10, padding:"10px 14px", color:COLORS.text, fontSize:16, fontWeight:700, outline:"none", boxSizing:"border-box", fontFamily:"inherit", marginBottom:8 }}/>
            <input value={location} onChange={e=>setLocation(e.target.value)} style={{ width:"100%", background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:10, padding:"8px 14px", color:COLORS.muted, fontSize:13, outline:"none", boxSizing:"border-box", fontFamily:"inherit" }} placeholder="📍 Tu ubicación"/>
          </div>
        ) : (
          <div style={{ marginBottom:8 }}>
            <h2 style={{ color:COLORS.text, fontSize:20, fontWeight:800, margin:"0 0 4px" }}>{name}</h2>
            <div style={{ color:COLORS.muted, fontSize:13 }}>📍 {location}</div>
          </div>
        )}

        {/* Badge verificación */}
        <div style={{ marginBottom:12 }}>
          {verified ? (
            <span style={{ background:"#3B82F622", border:"1px solid #3B82F655", color:"#3B82F6", borderRadius:20, padding:"4px 12px", fontSize:12, fontWeight:700 }}>✓ Perfil verificado</span>
          ) : (
            <button onClick={() => setVerifyStep("intro")} style={{ background:"#F59E0B22", border:"1px dashed #F59E0B88", color:"#F59E0B", borderRadius:20, padding:"5px 14px", fontSize:12, fontWeight:700, cursor:"pointer" }}>
              🛡️ Verificar perfil
            </button>
          )}
        </div>

        {/* Roles — editables */}
        <div style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:14, marginBottom:10 }}>
          <p style={{ color:COLORS.muted, fontSize:11, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", margin:"0 0 10px" }}>Soy</p>
          {editing ? (
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              {ALL_ROLES.map(r => (
                <button key={r} onClick={() => toggleRole(r)} style={{ padding:"6px 14px", borderRadius:20, border:`2px solid ${roles.includes(r)?COLORS.accent:COLORS.border}`, background:roles.includes(r)?COLORS.accent+"22":COLORS.surface, color:roles.includes(r)?COLORS.accent:COLORS.muted, fontSize:12, fontWeight:600, cursor:"pointer" }}>{r}</button>
              ))}
            </div>
          ) : (
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {roles.map(r=><Badge key={r}>{r}</Badge>)}
              <Badge color="#10B981" small>Activo hoy</Badge>
            </div>
          )}
        </div>

        {/* Bio */}
        <div style={{ marginBottom:10 }}>
          {editing
            ? <textarea value={bio} onChange={e=>setBio(e.target.value)} rows={3} placeholder="Contá brevemente quién sos..." style={{ width:"100%", background:COLORS.card, border:`1.5px solid ${COLORS.accent}`, borderRadius:12, padding:14, color:COLORS.text, fontSize:14, resize:"none", boxSizing:"border-box", fontFamily:"inherit" }}/>
            : <div style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:14 }}><p style={{ color:COLORS.text, fontSize:14, lineHeight:1.5, margin:0 }}>{bio}</p></div>
          }
        </div>

        {/* Stats */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8, marginBottom:12 }}>
          {[["12","Conexiones"],["3","Proyectos"],["89","Me gusta"]].map(([n,l])=>(
            <div key={l} style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:"11px 6px", textAlign:"center" }}>
              <div style={{ ...gradientText, fontSize:18, fontWeight:800 }}>{n}</div>
              <div style={{ color:COLORS.muted, fontSize:11 }}>{l}</div>
            </div>
          ))}
        </div>

        {/* Industrias — editables */}
        <div style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:14, marginBottom:10 }}>
          <p style={{ color:COLORS.muted, fontSize:11, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", margin:"0 0 10px" }}>Industrias</p>
          {editing ? (
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              {ALL_INDUSTRIES.map(i=>(
                <button key={i} onClick={() => toggleInd(i)} style={{ padding:"5px 12px", borderRadius:20, border:`2px solid ${industries.includes(i)?"#F59E0B":COLORS.border}`, background:industries.includes(i)?"#F59E0B22":COLORS.surface, color:industries.includes(i)?"#F59E0B":COLORS.muted, fontSize:12, fontWeight:600, cursor:"pointer" }}>{i}</button>
              ))}
            </div>
          ) : (
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {industries.map(i=><Badge key={i} color="#F59E0B" small>{i}</Badge>)}
            </div>
          )}
        </div>

        {/* Habilidades — editables */}
        <div style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:14, marginBottom:14 }}>
          <p style={{ color:COLORS.muted, fontSize:11, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", margin:"0 0 10px" }}>Habilidades</p>
          {editing ? (
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              {ALL_SKILLS.map(s=>(
                <button key={s} onClick={() => toggleSkill(s)} style={{ padding:"5px 12px", borderRadius:20, border:`2px solid ${skills.includes(s)?COLORS.accent:COLORS.border}`, background:skills.includes(s)?COLORS.accent+"22":COLORS.surface, color:skills.includes(s)?COLORS.accent:COLORS.muted, fontSize:12, fontWeight:600, cursor:"pointer" }}>{s}</button>
              ))}
            </div>
          ) : (
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {skills.map(s=><Badge key={s} color={COLORS.muted} small>{s}</Badge>)}
            </div>
          )}
        </div>

        {/* Proyectos */}
        <div style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:12, padding:14, marginBottom:16 }}>
          <p style={{ color:COLORS.muted, fontSize:11, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", margin:"0 0 8px" }}>Mis proyectos</p>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <div style={{ width:34, height:34, borderRadius:10, background:gradientBg, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16 }}>🚀</div>
            <div><div style={{ color:COLORS.text, fontWeight:700, fontSize:14 }}>CreditFlow</div><div style={{ color:COLORS.muted, fontSize:12 }}>MVP · Fintech</div></div>
            <Badge color="#3B82F6" small>MVP</Badge>
          </div>
        </div>

        <Btn full variant="ghost" onClick={onLogout} style={{ color:"#EF4444", borderColor:"#EF444433" }}>Cerrar sesión</Btn>
      </div>
    </div>
  );
};

// ── Sub-componentes de verificación ──────────────────────────────────────────
const ModalShell = ({ title, children, onClose, back }) => (
  <div style={{ position:"fixed", inset:0, background:"#00000099", zIndex:200, display:"flex", flexDirection:"column", justifyContent:"flex-end" }}>
    <div style={{ background:COLORS.surface, borderRadius:"22px 22px 0 0", padding:22, maxHeight:"88vh", overflowY:"auto" }}>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          {back && <button onClick={back} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:20, cursor:"pointer", padding:0 }}>←</button>}
          {title && <h3 style={{ color:COLORS.text, margin:0, fontSize:16 }}>{title}</h3>}
        </div>
        {onClose && <button onClick={onClose} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer" }}>✕</button>}
      </div>
      {children}
    </div>
  </div>
);

const VerifyUploadStep = ({ icon, label, hint, preview, onFile, onNext, nextLabel, disabled }) => (
  <div>
    <div style={{ textAlign:"center", marginBottom:16 }}>
      <div style={{ fontSize:36, marginBottom:8 }}>{icon}</div>
      <p style={{ color:COLORS.text, fontWeight:700, fontSize:15, margin:"0 0 4px" }}>{label}</p>
      <p style={{ color:COLORS.muted, fontSize:13 }}>{hint}</p>
    </div>
    <label style={{ display:"block", cursor:"pointer" }}>
      <div style={{ background:COLORS.card, border:`2px dashed ${preview?"#10B981":COLORS.border}`, borderRadius:14, padding:"20px 14px", textAlign:"center", marginBottom:16, transition:"border-color 0.2s" }}>
        {preview
          ? <img src={preview} alt="preview" style={{ maxWidth:"100%", maxHeight:160, borderRadius:10, objectFit:"cover" }}/>
          : <><div style={{ fontSize:32, marginBottom:8 }}>📁</div><p style={{ color:COLORS.muted, fontSize:13, margin:0 }}>Tocá para elegir una foto</p></>
        }
      </div>
      <input type="file" accept="image/*" onChange={onFile} style={{ display:"none" }}/>
    </label>
    {preview && <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:14 }}><span style={{ color:"#10B981", fontSize:14 }}>✓</span><span style={{ color:"#10B981", fontSize:13 }}>Foto cargada correctamente</span></div>}
    <Btn full onClick={onNext} style={{ opacity:disabled?0.45:1 }}>{nextLabel}</Btn>
  </div>
);

// ── Botón flotante arrastrable ────────────────────────────────────────────────
const DraggableBot = ({ onClick }) => {
  const [pos, setPos]         = useState({ x: null, y: null });
  const [dragging, setDragging] = useState(false);
  const [hasMoved, setHasMoved] = useState(false);
  const startRef              = useRef(null);
  const posRef                = useRef(pos);
  posRef.current              = pos;

  // Posición inicial: esquina inferior derecha
  useEffect(() => {
    setPos({ x: window.innerWidth > 430 ? 430 - 52 : window.innerWidth - 52, y: window.innerHeight - 140 });
  }, []);

  const onPointerDown = (e) => {
    e.preventDefault();
    setDragging(true);
    setHasMoved(false);
    startRef.current = { px: e.clientX - posRef.current.x, py: e.clientY - posRef.current.y };

    const onMove = (ev) => {
      const nx = ev.clientX - startRef.current.px;
      const ny = ev.clientY - startRef.current.py;
      // Clamp dentro del contenedor
      const maxX = Math.min(window.innerWidth, 430) - 42;
      const maxY = window.innerHeight - 42;
      setPos({ x: Math.max(0, Math.min(nx, maxX)), y: Math.max(0, Math.min(ny, maxY)) });
      setHasMoved(true);
    };
    const onUp = () => {
      setDragging(false);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  };

  if (pos.x === null) return null;

  return (
    <button
      onPointerDown={onPointerDown}
      onClick={() => { if (!hasMoved) onClick(); }}
      style={{
        position:"fixed", left:pos.x, top:pos.y, zIndex:800,
        width:42, height:42, borderRadius:"50%",
        background:gradientBg, border:"2px solid rgba(255,255,255,0.15)",
        cursor: dragging ? "grabbing" : "grab",
        display:"flex", alignItems:"center", justifyContent:"center",
        fontSize:18, boxShadow:"0 3px 14px rgba(168,85,247,0.5)",
        transition: dragging ? "none" : "box-shadow 0.2s",
        animation: dragging ? "none" : "botPulse 2.5s ease-in-out infinite",
        touchAction:"none",
      }}
      title="PiperBot — arrastrá para mover"
    >
      🤖
    </button>
  );
};

// ── PiperBot — Asistente IA ───────────────────────────────────────────────────
const QUICK_QUESTIONS = [
  "¿Cómo mejoro mi perfil para atraer inversores?",
  "¿Qué tipo de publicación genera más conexiones?",
  "¿Cómo preparo mi pitch para una ronda seed?",
  "¿Cómo evalúo a un posible cofundador/a?",
  "¿Qué debo buscar al sumarme a un proyecto?",
  "¿Cómo verifico mi perfil paso a paso?",
  "¿Cómo funciona el sistema de Match?",
  "¿Qué diferencia hay entre los tipos de usuario?",
];

const SYSTEM_PROMPT = `Sos PiperBot, el asistente inteligente de WePiper — la red profesional de LATAM que conecta emprendedores, inversores, profesionales y proveedores.

Tu rol es ayudar a los usuarios a sacar el máximo provecho de la plataforma y orientarlos en su camino emprendedor o profesional dentro del ecosistema LATAM.

Respondé siempre en español argentino (voseo), de forma concisa, cálida y práctica. Máximo 3-4 párrafos por respuesta. Usá emojis con moderación para dar calidez. Si la pregunta es muy amplia, pedí más contexto de forma amable.

Sobre WePiper sabés que:
- Tiene un sistema de Match que conecta usuarios por industria, habilidades y etapa de proyecto
- Los usuarios pueden ser Profesionales, Emprendedores/as, Inversores/as o Proveedores/as
- Hay un feed de publicaciones con tipos: busco cofundador/a, busco inversor/a, ofrezco servicios, oportunidad de proyecto
- Los proyectos tienen etapas: Idea, MVP, Crecimiento, Escalando
- Los perfiles se pueden verificar con DNI y validación facial para mayor confianza
- El chat se habilita cuando hay match mutuo entre dos usuarios
- Siempre respondé desde el contexto de WePiper y el ecosistema emprendedor de LATAM`;

const PiperBot = ({ onClose }) => {
  const [messages, setMessages] = useState([
    { role:"assistant", text:"¡Hola! Soy PiperBot 🤖✨ Tu asistente en WePiper. ¿En qué te puedo ayudar hoy? Podés escribirme lo que quieras o elegir una pregunta rápida 👇" }
  ]);
  const [input, setInput]       = useState("");
  const [loading, setLoading]   = useState(false);
  const [showQuick, setShowQuick] = useState(true);
  const msgsEndRef              = useRef(null);

  useEffect(() => {
    msgsEndRef.current?.scrollIntoView({ behavior:"smooth" });
  }, [messages, loading]);

  const sendMessage = async (text) => {
    if (!text.trim() || loading) return;
    const userMsg = { role:"user", text };
    const newMsgs = [...messages, userMsg];
    setMessages(newMsgs);
    setInput("");
    setShowQuick(false);
    setLoading(true);

    try {
      const history = newMsgs.map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.text }));
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: history,
        }),
      });
      const data = await res.json();
      const reply = data.content?.map(b => b.text).join("") || "Lo siento, no pude procesar tu consulta. Intentá de nuevo.";
      setMessages(prev => [...prev, { role:"assistant", text: reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role:"assistant", text:"Ups, hubo un problema de conexión. ¿Podés intentarlo de nuevo? 🙏" }]);
    } finally {
      setLoading(false);
    }
  };

  const handleQuick = (q) => sendMessage(q);

  return (
    <div style={{ position:"fixed", inset:0, zIndex:900, display:"flex", flexDirection:"column", justifyContent:"flex-end", background:"rgba(0,0,0,0.6)", backdropFilter:"blur(4px)" }}
      onClick={onClose}>
      <div style={{ background:COLORS.surface, borderRadius:"24px 24px 0 0", maxHeight:"82vh", display:"flex", flexDirection:"column", boxShadow:"0 -8px 40px rgba(0,0,0,0.5)" }}
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div style={{ padding:"16px 18px 12px", borderBottom:`1px solid ${COLORS.border}`, display:"flex", alignItems:"center", gap:12, flexShrink:0 }}>
          <div style={{ width:40, height:40, borderRadius:"50%", background:gradientBg, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, boxShadow:"0 0 16px #A855F755" }}>🤖</div>
          <div style={{ flex:1 }}>
            <div style={{ color:COLORS.text, fontWeight:700, fontSize:15 }}>PiperBot</div>
            <div style={{ color:"#10B981", fontSize:11 }}>● Siempre disponible</div>
          </div>
          <button onClick={onClose} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:22, cursor:"pointer", padding:4 }}>✕</button>
        </div>

        {/* Messages */}
        <div style={{ flex:1, overflowY:"auto", padding:"14px 16px", display:"flex", flexDirection:"column", gap:10, minHeight:0 }}>
          {messages.map((m, i) => (
            <div key={i} style={{ display:"flex", justifyContent:m.role==="user"?"flex-end":"flex-start", alignItems:"flex-end", gap:8 }}>
              {m.role==="assistant" && (
                <div style={{ width:28, height:28, borderRadius:"50%", background:gradientBg, display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, flexShrink:0 }}>🤖</div>
              )}
              <div style={{
                background: m.role==="user" ? gradientBg : COLORS.card,
                border: m.role==="user" ? "none" : `1px solid ${COLORS.border}`,
                borderRadius: m.role==="user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
                padding:"10px 14px", maxWidth:"80%",
              }}>
                <p style={{ color:"#fff", fontSize:13, lineHeight:1.55, margin:0, whiteSpace:"pre-wrap" }}>{m.text}</p>
              </div>
            </div>
          ))}

          {/* Typing indicator */}
          {loading && (
            <div style={{ display:"flex", alignItems:"flex-end", gap:8 }}>
              <div style={{ width:28, height:28, borderRadius:"50%", background:gradientBg, display:"flex", alignItems:"center", justifyContent:"center", fontSize:13 }}>🤖</div>
              <div style={{ background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:"18px 18px 18px 4px", padding:"12px 16px" }}>
                <div style={{ display:"flex", gap:4, alignItems:"center" }}>
                  {[0,1,2].map(i => (
                    <div key={i} style={{ width:6, height:6, borderRadius:"50%", background:COLORS.muted, animation:`typingDot 1.2s ease-in-out ${i*0.2}s infinite` }}/>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Quick questions */}
          {showQuick && !loading && (
            <div style={{ marginTop:4 }}>
              <p style={{ color:COLORS.muted, fontSize:11, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:8 }}>Preguntas frecuentes</p>
              <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                {QUICK_QUESTIONS.map((q, i) => (
                  <button key={i} onClick={() => handleQuick(q)} style={{
                    background:COLORS.bg, border:`1px solid ${COLORS.border}`,
                    borderRadius:10, padding:"9px 12px", color:COLORS.text,
                    fontSize:12, textAlign:"left", cursor:"pointer", lineHeight:1.4,
                    transition:"border-color 0.2s",
                  }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = COLORS.accent}
                    onMouseLeave={e => e.currentTarget.style.borderColor = COLORS.border}>
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {!showQuick && !loading && messages.length > 1 && (
            <button onClick={() => setShowQuick(true)} style={{ alignSelf:"center", background:"none", border:`1px solid ${COLORS.border}`, borderRadius:20, padding:"5px 14px", color:COLORS.muted, fontSize:11, cursor:"pointer", marginTop:4 }}>
              Ver preguntas frecuentes
            </button>
          )}

          <div ref={msgsEndRef}/>
        </div>

        {/* Input */}
        <div style={{ padding:"10px 14px 16px", borderTop:`1px solid ${COLORS.border}`, display:"flex", gap:10, flexShrink:0 }}>
          <input
            value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key==="Enter" && !e.shiftKey && sendMessage(input)}
            placeholder="Escribí tu consulta..."
            disabled={loading}
            style={{ flex:1, background:COLORS.card, border:`1px solid ${COLORS.border}`, borderRadius:24, padding:"11px 16px", color:COLORS.text, fontSize:13, outline:"none", fontFamily:"inherit", opacity:loading?0.6:1 }}
          />
          <button onClick={() => sendMessage(input)} disabled={loading || !input.trim()} style={{ width:44, height:44, borderRadius:"50%", background:input.trim()&&!loading?gradientBg:COLORS.border, border:"none", color:"#fff", fontSize:18, cursor:input.trim()&&!loading?"pointer":"default", flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", transition:"background 0.2s" }}>
            {loading ? "⏳" : "➤"}
          </button>
        </div>
      </div>
      <style>{`@keyframes typingDot { 0%,100%{transform:translateY(0);opacity:0.4} 50%{transform:translateY(-4px);opacity:1} }`}</style>
    </div>
  );
};

// ── UserProfileModal — vista de perfil de otro usuario ────────────────────────
const UserProfileModal = ({ u, onClose }) => (
  <div style={{ position:"fixed", inset:0, zIndex:500, background:"rgba(0,0,0,0.7)", backdropFilter:"blur(4px)", display:"flex", flexDirection:"column", justifyContent:"flex-end" }}
    onClick={onClose}>
    <div style={{ background:COLORS.surface, borderRadius:"24px 24px 0 0", maxHeight:"88vh", overflowY:"auto", boxShadow:"0 -8px 40px rgba(0,0,0,0.5)" }}
      onClick={e => e.stopPropagation()}>
      {/* Cover */}
      <div style={{ height:100, background:u.avatarBg || gradientBg, position:"relative", borderRadius:"24px 24px 0 0" }}>
        <button onClick={onClose} style={{ position:"absolute", top:14, right:14, background:"rgba(0,0,0,0.35)", border:"none", borderRadius:"50%", width:32, height:32, color:"#fff", fontSize:16, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>✕</button>
      </div>
      <div style={{ padding:"0 18px 32px" }}>
        {/* Avatar */}
        <div style={{ marginTop:-32, marginBottom:10 }}>
          <div style={{ width:64, height:64, borderRadius:"50%", background:u.avatarBg||gradientBg, border:`3px solid ${COLORS.surface}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:1 }}>
            <span style={{ fontSize:22 }}>{u.emoji||"👤"}</span>
            <span style={{ color:"#fff", fontSize:11, fontWeight:800 }}>{u.avatar}</span>
          </div>
        </div>
        {/* Name */}
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}>
          <h2 style={{ color:COLORS.text, fontSize:18, fontWeight:800, margin:0 }}>{u.name}</h2>
          {u.verified && <span style={{ fontSize:14 }}>✅</span>}
        </div>
        <div style={{ color:COLORS.muted, fontSize:13, marginBottom:12 }}>📍 {u.location}</div>
        {/* Roles */}
        <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:12 }}>
          {(u.role||[]).map(r => <Badge key={r} small>{r}</Badge>)}
          {u.active && <Badge color="#10B981" small>● Online</Badge>}
        </div>
        {/* Bio */}
        <p style={{ color:COLORS.text, fontSize:14, lineHeight:1.6, marginBottom:14 }}>{u.bio}</p>
        {/* Industrias */}
        {u.industries?.length > 0 && <>
          <p style={{ color:COLORS.muted, fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", margin:"0 0 6px" }}>Industrias</p>
          <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:12 }}>
            {u.industries.map(i => <Badge key={i} color="#F59E0B" small>{i}</Badge>)}
          </div>
        </>}
        {/* Skills */}
        {u.skills?.length > 0 && <>
          <p style={{ color:COLORS.muted, fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em", margin:"0 0 6px" }}>Habilidades</p>
          <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:20 }}>
            {u.skills.map(s => <Badge key={s} color={COLORS.muted} small>{s}</Badge>)}
          </div>
        </>}
        <Btn full onClick={onClose}>Cerrar</Btn>
      </div>
    </div>
  </div>
);

// ── Tutorial interactivo (primera vez) ───────────────────────────────────────
const TUTORIAL_STEPS = [
  { target:"home",     label:"🏠 Inicio",     desc:"Acá encontrás el feed con publicaciones de la comunidad. Podés publicar oportunidades y conectar con otros Pipers.",       position:"top" },
  { target:"discover", label:"⚡ Match",       desc:"Tocá la W para descubrir Pipers afines. Deslizá a la derecha para enviar una solicitud de conexión.",                      position:"top" },
  { target:"projects", label:"🚀 Proyectos",   desc:"Explorá proyectos activos que buscan colaboradores, inversores o proveedores. También podés publicar el tuyo.",            position:"top" },
  { target:"messages", label:"💬 Mensajes",    desc:"Cuando una conexión es mutua, se habilita el chat. Aquí encontrás todas tus conversaciones.",                              position:"top" },
  { target:"profile",  label:"👤 Tu perfil",   desc:"Completá tu perfil al máximo para aparecer más en los matcheos. También podés verificar tu identidad con DNI.",           position:"top" },
  { target:"bot",      label:"🤖 PiperBot",    desc:"Este es tu asistente inteligente. Preguntale cualquier cosa sobre WePiper o el ecosistema emprendedor de LATAM.",          position:"bottom" },
];

const Tutorial = ({ onDone }) => {
  const [step, setStep] = useState(0);
  const current = TUTORIAL_STEPS[step];
  const isLast = step === TUTORIAL_STEPS.length - 1;

  // Tab index to highlight
  const tabOrder = ["home","projects","discover","messages","profile"];
  const tabIdx = tabOrder.indexOf(current.target);

  return (
    <div style={{ position:"fixed", inset:0, zIndex:1000, pointerEvents:"none" }}>
      {/* Dimmed overlay */}
      <div style={{ position:"absolute", inset:0, background:"rgba(0,0,0,0.78)" }}/>

      {/* Highlight spotlight on nav tab */}
      {current.target !== "bot" && tabIdx >= 0 && (
        <div style={{
          position:"absolute", bottom: current.target==="discover" ? 18 : 52,
          left: `${(tabIdx / 5) * 100 + 10}%`,
          width: current.target==="discover" ? 58 : 52, height: current.target==="discover" ? 58 : 40,
          borderRadius:"50%", border:"3px solid #A855F7",
          boxShadow:"0 0 0 4px rgba(168,85,247,0.3), 0 0 24px rgba(168,85,247,0.6)",
          animation:"tutPulse 1.2s ease-in-out infinite",
        }}/>
      )}
      {current.target === "bot" && (
        <div style={{
          position:"absolute", bottom:84, right:16,
          width:48, height:48, borderRadius:"50%",
          border:"3px solid #A855F7",
          boxShadow:"0 0 0 4px rgba(168,85,247,0.3), 0 0 24px rgba(168,85,247,0.6)",
          animation:"tutPulse 1.2s ease-in-out infinite",
        }}/>
      )}

      {/* Tooltip card */}
      <div style={{
        position:"absolute",
        bottom: current.target==="bot" ? 140 : 130,
        left:"50%", transform:"translateX(-50%)",
        width:300, background:COLORS.surface,
        border:`1px solid ${COLORS.accent}55`,
        borderRadius:18, padding:20,
        boxShadow:"0 8px 40px rgba(168,85,247,0.3)",
        pointerEvents:"all",
      }}>
        <div style={{ fontSize:13, fontWeight:800, color:COLORS.accent, marginBottom:6 }}>{current.label}</div>
        <p style={{ color:COLORS.text, fontSize:13, lineHeight:1.6, margin:"0 0 16px" }}>{current.desc}</p>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div style={{ display:"flex", gap:5 }}>
            {TUTORIAL_STEPS.map((_,i) => (
              <div key={i} style={{ width: i===step?18:6, height:6, borderRadius:3, background:i===step?COLORS.accent:COLORS.border, transition:"width 0.3s" }}/>
            ))}
          </div>
          <button onClick={() => isLast ? onDone() : setStep(s=>s+1)} style={{ background:gradientBg, border:"none", borderRadius:10, padding:"8px 18px", color:"#fff", fontWeight:700, fontSize:13, cursor:"pointer" }}>
            {isLast ? "¡Empezar! 🚀" : "Siguiente →"}
          </button>
        </div>
        {!isLast && <button onClick={onDone} style={{ position:"absolute", top:12, right:14, background:"none", border:"none", color:COLORS.muted, fontSize:12, cursor:"pointer" }}>Omitir</button>}
      </div>
      <style>{`@keyframes tutPulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.7;transform:scale(1.08)} }`}</style>
    </div>
  );
};

// ── Guest wall — bloquea acciones a invitados ─────────────────────────────────
const GuestWall = ({ onGoRegister }) => (
  <div style={{ height:"100%", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32, textAlign:"center", background:COLORS.bg }}>
    <div style={{ fontSize:56, marginBottom:16 }}>🔒</div>
    <h2 style={{ color:COLORS.text, fontSize:20, fontWeight:800, margin:"0 0 10px" }}>Registrate para continuar</h2>
    <p style={{ color:COLORS.muted, fontSize:14, lineHeight:1.7, marginBottom:28, maxWidth:260 }}>
      Como invitado solo podés ver las publicaciones del feed. Creá tu cuenta gratis para conectar, matchear y mucho más.
    </p>
    <Btn full onClick={onGoRegister} style={{ maxWidth:260 }}>Crear cuenta gratis →</Btn>
    <p style={{ color:COLORS.muted, fontSize:12, marginTop:14 }}>¿Ya tenés cuenta? <button onClick={onGoRegister} style={{ background:"none", border:"none", color:COLORS.accent, cursor:"pointer", fontSize:12, fontWeight:600 }}>Iniciá sesión</button></p>
  </div>
);

// ── Hamburger menu con solicitudes enviadas ───────────────────────────────────
const HamburgerMenu = ({ onClose, sentRequests, onGoRegister, isGuest }) => (
  <div style={{ position:"fixed", inset:0, zIndex:600 }} onClick={onClose}>
    <div style={{ position:"absolute", top:0, left:0, width:280, height:"100%", background:COLORS.surface, borderRight:`1px solid ${COLORS.border}`, display:"flex", flexDirection:"column", boxShadow:"8px 0 32px rgba(0,0,0,0.5)" }}
      onClick={e=>e.stopPropagation()}>
      {/* Header */}
      <div style={{ padding:"52px 20px 20px", borderBottom:`1px solid ${COLORS.border}` }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <span style={{ ...gradientText, fontSize:18, fontWeight:900 }}>WePiper</span>
          <button onClick={onClose} style={{ background:"none", border:"none", color:COLORS.muted, fontSize:20, cursor:"pointer" }}>✕</button>
        </div>
      </div>

      {/* Solicitudes enviadas */}
      <div style={{ flex:1, overflowY:"auto", padding:"16px 0" }}>
        <div style={{ padding:"0 20px 10px" }}>
          <p style={{ color:COLORS.muted, fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.1em", margin:"0 0 12px" }}>📨 Solicitudes enviadas</p>
          {sentRequests.length === 0 ? (
            <p style={{ color:COLORS.muted, fontSize:13, fontStyle:"italic" }}>Todavía no enviaste solicitudes.</p>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {sentRequests.map(u => (
                <div key={u.id} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 12px", background:COLORS.card, borderRadius:12, border:`1px solid ${COLORS.border}` }}>
                  <div style={{ width:36, height:36, borderRadius:"50%", background:u.avatarBg||gradientBg, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                    <span style={{ fontSize:14 }}>{u.emoji||"👤"}</span>
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ color:COLORS.text, fontWeight:700, fontSize:13, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{u.name}</div>
                    <div style={{ color:COLORS.muted, fontSize:11 }}>{(u.role||[]).join(", ")}</div>
                  </div>
                  <span style={{ background:"#F59E0B22", border:"1px solid #F59E0B55", color:"#F59E0B", fontSize:10, fontWeight:700, borderRadius:20, padding:"2px 8px", flexShrink:0 }}>Pendiente</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={{ height:1, background:COLORS.border, margin:"16px 0" }}/>

        <div style={{ padding:"0 20px" }}>
          <p style={{ color:COLORS.muted, fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.1em", margin:"0 0 12px" }}>Más</p>
          {isGuest ? (
            <button onClick={onGoRegister} style={{ display:"flex", alignItems:"center", gap:10, background:"none", border:"none", color:COLORS.text, fontSize:14, cursor:"pointer", padding:"8px 0", width:"100%" }}>
              <span style={{ fontSize:18 }}>🔑</span> Crear cuenta / Iniciar sesión
            </button>
          ) : null}
          <button style={{ display:"flex", alignItems:"center", gap:10, background:"none", border:"none", color:COLORS.muted, fontSize:14, cursor:"pointer", padding:"8px 0", width:"100%" }}>
            <span style={{ fontSize:18 }}>⚙️</span> Configuración
          </button>
          <button style={{ display:"flex", alignItems:"center", gap:10, background:"none", border:"none", color:COLORS.muted, fontSize:14, cursor:"pointer", padding:"8px 0", width:"100%" }}>
            <span style={{ fontSize:18 }}>❓</span> Ayuda
          </button>
        </div>
      </div>

      <div style={{ padding:"16px 20px", borderTop:`1px solid ${COLORS.border}` }}>
        <p style={{ color:COLORS.muted, fontSize:10, textAlign:"center", letterSpacing:"0.1em" }}>WePiper · by 4His</p>
      </div>
    </div>
  </div>
);

// ── App principal ─────────────────────────────────────────────────────────────
export default function WePiper() {
  const [screen, setScreen]           = useState("splash");
  const [activeTab, setActiveTab]     = useState("home");
  const [user, setUser]               = useState(null);
  const [showBot, setShowBot]         = useState(false);
  const [connections, setConnections] = useState(INITIAL_CONNECTIONS);
  const [viewingUser, setViewingUser] = useState(null);
  const [showTutorial, setShowTutorial] = useState(false);
  const [showMenu, setShowMenu]       = useState(false);
  const [sentRequests, setSentRequests] = useState([]); // array of user objects
  const [notifications, setNotifs]    = useState([
    { id:1, icon:"🤝", text:"Mateo Rivera aceptó tu conexión. ¡Ahora pueden chatear!", time:"hace 1h", read:false }
  ]);

  const handleAuth    = u => { setUser(u); if(u.guest){ setScreen("app"); } else if(u.isNewUser){ setScreen("onboarding"); } else { setScreen("app"); } };
  const handleOnboard = roles => { setUser(u=>({...u,roles})); setScreen("app"); setShowTutorial(true); };
  const handleConnect = id   => setConnections(c=>[...new Set([...c,id])]);
  const addNotif      = n    => setNotifs(prev=>[n,...prev]);
  const clearNotifs   = ()   => setNotifs(prev=>prev.map(n=>({...n,read:true})));
  const handleLogout  = ()   => { setUser(null); setScreen("auth"); setActiveTab("home"); setConnections(INITIAL_CONNECTIONS); setSentRequests([]); };
  const handleSentRequest = (u) => setSentRequests(prev => prev.find(x=>x.id===u.id) ? prev : [...prev, u]);

  const unreadCount = notifications.filter(n=>!n.read).length;

  const tabs = [
    { id:"home",     icon:"🏠",  label:"Inicio"    },
    { id:"projects", icon:"🚀",  label:"Proyectos" },
    { id:"discover", icon:null,  label:"Match",  isW:true },
    { id:"messages", icon:"💬",  label:"Mensajes"  },
    { id:"profile",  icon:"👤",  label:"Perfil"    },
  ];

  return (
    <div style={{ width:"100%", height:"100vh", display:"flex", justifyContent:"center", background:"#060608", fontFamily:"Georgia, serif" }}>
      <div style={{ width:"100%", maxWidth:430, height:"100vh", background:COLORS.bg, overflow:"hidden", display:"flex", flexDirection:"column", boxShadow:"0 0 80px #7C3AED33" }}>
        {screen==="splash"     && <Splash onDone={() => setScreen("auth")}/>}
        {screen==="auth"       && <Auth onAuth={handleAuth}/>}
        {screen==="onboarding" && <Onboarding onDone={handleOnboard}/>}
        {screen==="app" && (
          <>
            <div style={{ flex:1, overflow:"hidden" }}>
              {activeTab==="home"     && <Home user={user||{}} notifications={notifications} onClearNotif={clearNotifs} onViewUser={setViewingUser} onOpenMenu={() => setShowMenu(true)} isGuest={user?.guest}/>}
              {activeTab==="discover" && (user?.guest
                ? <GuestWall onGoRegister={() => { setUser(null); setScreen("auth"); }}/>
                : <Discover connections={connections} onConnect={handleConnect} onAddNotif={addNotif} onViewUser={setViewingUser} onSentRequest={handleSentRequest}/>
              )}
              {activeTab==="projects" && (user?.guest
                ? <GuestWall onGoRegister={() => { setUser(null); setScreen("auth"); }}/>
                : <Projects/>
              )}
              {activeTab==="messages" && (user?.guest
                ? <GuestWall onGoRegister={() => { setUser(null); setScreen("auth"); }}/>
                : <Messages user={user||{}} connections={connections}/>
              )}
              {activeTab==="profile"  && (user?.guest
                ? <GuestWall onGoRegister={() => { setUser(null); setScreen("auth"); }}/>
                : <Profile user={user||{}} onLogout={handleLogout}/>
              )}
            </div>

            {/* Tutorial overlay */}
            {showTutorial && <Tutorial onDone={() => setShowTutorial(false)}/>}

            {/* Hamburger menu */}
            {showMenu && <HamburgerMenu onClose={() => setShowMenu(false)} sentRequests={sentRequests} onGoRegister={() => { setShowMenu(false); setUser(null); setScreen("auth"); }} isGuest={user?.guest}/>}

            {/* User profile preview modal */}
            {viewingUser && <UserProfileModal u={viewingUser} onClose={() => setViewingUser(null)}/>}

            {/* Bot */}
            {showBot && <PiperBot onClose={() => setShowBot(false)}/>}
            {!showBot && <DraggableBot onClick={() => setShowBot(true)}/>}

            {/* Barra de navegación con W central */}
            <div style={{ display:"flex", alignItems:"flex-end", background:COLORS.surface, borderTop:`1px solid ${COLORS.border}`, padding:"6px 0 8px" }}>
              {tabs.map(tab => {
                const isActive = activeTab===tab.id;
                if (tab.isW) return (
                  <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ flex:1, background:"none", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:2, padding:0 }}>
                    <div style={{ width:52, height:52, borderRadius:"50%", background:isActive?gradientBg:"linear-gradient(135deg,#5B21B6,#9333EA)", display:"flex", alignItems:"center", justifyContent:"center", marginBottom:2, marginTop:-20, boxShadow:isActive?"0 0 20px #A855F788":"0 4px 16px #00000066", border:`3px solid ${COLORS.surface}` }}>
                      <span style={{ color:"#fff", fontSize:22, fontWeight:900, fontFamily:"Georgia,serif", lineHeight:1 }}>W</span>
                    </div>
                    <span style={{ fontSize:9, fontWeight:600, color:isActive?COLORS.accent:COLORS.muted, fontFamily:"system-ui" }}>{tab.label}</span>
                  </button>
                );
                // Badge en mensajes si hay conexiones nuevas
                const showBadge = tab.id==="messages" && connections.length > INITIAL_CONNECTIONS.length;
                return (
                  <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ flex:1, background:"none", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:2, padding:"5px 0", position:"relative" }}>
                    <span style={{ fontSize:20, filter:isActive?"none":"grayscale(0.8) opacity(0.5)" }}>{tab.icon}</span>
                    {showBadge && <div style={{ position:"absolute", top:2, right:"25%", width:7, height:7, background:"#EC4899", borderRadius:"50%" }}/>}
                    <span style={{ fontSize:9, fontWeight:600, color:isActive?COLORS.accent:COLORS.muted, fontFamily:"system-ui" }}>{tab.label}</span>
                    {isActive && <div style={{ width:4, height:4, borderRadius:"50%", background:COLORS.accent }}/>}
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>
      <style>{`* { box-sizing:border-box; } ::-webkit-scrollbar { width:3px; } ::-webkit-scrollbar-thumb { background:${COLORS.border}; border-radius:4px; } select option { background:${COLORS.card}; } @keyframes botPulse { 0%,100%{box-shadow:0 4px 20px rgba(168,85,247,0.5)} 50%{box-shadow:0 4px 32px rgba(236,72,153,0.7)} }`}</style>
    </div>
  );
}
